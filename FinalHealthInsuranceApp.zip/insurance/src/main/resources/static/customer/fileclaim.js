$(document).ready(function() {
	$("#myButton").click(function() {
		event.preventDefault();
		const id = $("#policyIdId").val();
		$.ajax({
			type: "GET",
			url: "/customer/getFamilyMembers?policy=" + id,
			contentType: "application/json;charset=UTF-8",
			success: function(response) {
				var mem = $("#members");
				mem.empty();
				if (Array.isArray(response) && response.length > 0) {
					for (let i = 0; i < response.length; i++) {
						mem.append($("<option>", {
							text: response[i],
							value: response[i]
						}));
					}
				} else {
					window.alert("You are unable to apply for this claim.");
				}
			}
		});

	});

	$("#addDocumentButton").click(function() {
		const documentRow = createDocumentRow();
		$("#documentFields").append(documentRow);
	});

	function createDocumentRow() {
		const documentRow = $("<div>").addClass("document-row");

		const documentNameInput = $("<input>").attr({
			type: "text",
			name: "documentTitle",
			placeholder: "Document Name",
			required: true
		}).addClass("document-input");

		const documentAmountInput = $("<input>").attr({
			type: "number",
			name: "claimAmount",
			placeholder: "Amount",
			required: true
		}).addClass("document-input");

		const documentFileInput = $("<input>").attr({
			type: "file",
			name: "file[]",
			accept: ".pdf, .jpg, .png",
			required: true
		}).addClass("document-file-input");

		const removeDocumentButton = $("<button>").attr({
			type: "button"
		}).addClass("remove-document-button").text("Remove File");

		removeDocumentButton.click(function() {
			documentRow.remove();
		});

		documentRow.append(
			documentNameInput,
			documentAmountInput,
			documentFileInput,
			removeDocumentButton
		);
		return documentRow;
	}
	$('#claimbutton').click(function(event) {
		event.preventDefault();
		$('#claimForm').submit();
		//window.location.href ='viewflow.html';

	});
});
