package com.insurance.Customeroptions.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.jdbc.core.JdbcTemplate;

import com.insurance.Customeroptions.dao.CustomerPaymentDAO;
import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicyPayment;
import com.insurance.Customeroptions.rowmapper.InsurancePolicyCoverageMemberMapper;
import com.insurance.Customeroptions.rowmapper.InsurancePolicyPaymentMapper;

public class CustomerPaymentDAOTest {

	@InjectMocks
	private CustomerPaymentDAO customerPaymentDAO;

	@Mock
	private JdbcTemplate jdbcTemplate;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}

	@Test
	public void testCreatePayment() {

		InsurancePolicyPayment payment = new InsurancePolicyPayment();
		payment.setPolicyId(1);
		payment.setTransactionId("12345");
		payment.setAmount(100.0);
		payment.setPaymentMode("Credit Card");
		payment.setTransDate(new Date(System.currentTimeMillis()));


		when(jdbcTemplate.update(anyString(), any(), any(), any(), any(), any())).thenReturn(1);


		boolean result = customerPaymentDAO.createPayment(payment);
		verify(jdbcTemplate, times(1)).update(anyString(), any(), any(), any(), any(), any());
		assertEquals(true, result);
	}

	@Test
	public void testGetAllInsurancePolicyPaymentsList() {

		List<InsurancePolicyPayment> dummyPayments = new ArrayList<>();
		dummyPayments.add(new InsurancePolicyPayment());
		dummyPayments.add(new InsurancePolicyPayment());


		when(jdbcTemplate.query(anyString(), any(InsurancePolicyPaymentMapper.class))).thenReturn(dummyPayments);

		List<InsurancePolicyPayment> result = customerPaymentDAO.getAllInsurancePolicyPaymentsList();
		verify(jdbcTemplate, times(1)).query(anyString(), any(InsurancePolicyPaymentMapper.class));
		assertEquals(dummyPayments, result);
	}

	@Test
	public void testGetAllFirstPolicy() {

		List<InsurancePolicyPayment> dummyPayments = new ArrayList<>();
		dummyPayments.add(new InsurancePolicyPayment());
		dummyPayments.add(new InsurancePolicyPayment());


		when(jdbcTemplate.query(anyString(), any(InsurancePolicyPaymentMapper.class), anyInt())).thenReturn(dummyPayments);


		List<InsurancePolicyPayment> result = customerPaymentDAO.getAllFirstPolicy(1);
		verify(jdbcTemplate, times(1)).query(anyString(), any(InsurancePolicyPaymentMapper.class), anyInt());
		assertEquals(dummyPayments, result);
	}

	@Test
	public void testUpdateTransactionId() {

		when(jdbcTemplate.update(anyString(), any(), any(), anyInt(), anyInt())).thenReturn(1);


		boolean result = customerPaymentDAO.updateTransactionId(1, "12345", new Date(System.currentTimeMillis()));
		verify(jdbcTemplate, times(1)).update(anyString(), any(), any(), anyInt(), anyInt());
		assertEquals(true, result);
	}

	@Test
	public void testGetAllCustPayments() {

		List<InsurancePolicyPayment> dummyPayments = new ArrayList<>();
		dummyPayments.add(new InsurancePolicyPayment());
		dummyPayments.add(new InsurancePolicyPayment());


		when(jdbcTemplate.query(anyString(), any(InsurancePolicyPaymentMapper.class), anyInt())).thenReturn(dummyPayments);


		List<InsurancePolicyPayment> result = customerPaymentDAO.getAllCustPayments(1);
		verify(jdbcTemplate, times(1)).query(anyString(), any(InsurancePolicyPaymentMapper.class), anyInt());
		assertEquals(dummyPayments, result);
	}

	@Test
	public void testInsertIPCM() {

		InsurancePolicyCoverageMembers ipcm = new InsurancePolicyCoverageMembers();
		ipcm.setIpcmMemberName("John Doe");
		ipcm.setIpcmRelation("Spouse");
		ipcm.setIpcmDob(new Date(System.currentTimeMillis()));

		ipcm.setIpcmHealthHistory("Good");


		when(jdbcTemplate.update(anyString(), any(), any(), any(), any(), any(), anyInt())).thenReturn(1);


		boolean result = customerPaymentDAO.InsertIPCM(ipcm, 1);
		verify(jdbcTemplate, times(1)).update(anyString(), any(), any(), any(), any(), any(), anyInt());
		assertEquals(true, result);
	}

	@Test
	public void testGetAllIPCMList() {

		List<InsurancePolicyCoverageMembers> dummyIPCMList = new ArrayList<>();
		dummyIPCMList.add(new InsurancePolicyCoverageMembers());
		dummyIPCMList.add(new InsurancePolicyCoverageMembers());


		when(jdbcTemplate.query(anyString(), any(InsurancePolicyCoverageMemberMapper.class))).thenReturn(dummyIPCMList);


		List<InsurancePolicyCoverageMembers> result = customerPaymentDAO.getAllIPCMList();
		verify(jdbcTemplate, times(1)).query(anyString(), any(InsurancePolicyCoverageMemberMapper.class));
		assertEquals(dummyIPCMList, result);
	}

	@Test
	public void testGetCountNullTransId() {

		when(jdbcTemplate.queryForObject(anyString(), eq(Integer.class), anyInt())).thenReturn(2);


		int result = customerPaymentDAO.getCountNullTransId(1);
		verify(jdbcTemplate, times(1)).queryForObject(anyString(), eq(Integer.class), anyInt());
		assertEquals(2, result);
	}
}