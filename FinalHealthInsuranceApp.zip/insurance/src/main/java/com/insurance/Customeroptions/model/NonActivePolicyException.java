package com.insurance.Customeroptions.model;

public class NonActivePolicyException extends RuntimeException {

    public NonActivePolicyException(String message) {
        super(message);
    }
}
