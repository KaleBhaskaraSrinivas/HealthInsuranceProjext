package com.insurance.Customeroptions.test;


import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;

import com.insurance.Customeroptions.contracts.InterfaceInsurancePackageAndPolicyRepository;
import com.insurance.Customeroptions.controller.CustomerOptionsController;
import com.insurance.Customeroptions.model.Faq;
import com.insurance.Customeroptions.model.FormData;
import com.insurance.Customeroptions.model.InsurancePackages;
import com.insurance.Customeroptions.model.InsurancePolicy;

import jakarta.servlet.http.HttpSession;

@RunWith(MockitoJUnitRunner.class)
public class CustomerOptionsControllerTest {

	@InjectMocks
	private CustomerOptionsController customerOptionsController;

	@Mock
	private InterfaceInsurancePackageAndPolicyRepository irrp;

	@Mock
	private Model model;

	@Mock
	private HttpSession session;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testGetAllInsurancePolicies() {
		List<InsurancePolicy> insurancePolicies = new ArrayList<>();
		//policy id and cust_id
		InsurancePolicy policy1 = new InsurancePolicy();
		InsurancePolicy policy2 = new InsurancePolicy();
		InsurancePolicy policy3 = new InsurancePolicy();
		InsurancePolicy policy4 = new InsurancePolicy();

		insurancePolicies.add(policy1);
		insurancePolicies.add(policy2);
		insurancePolicies.add(policy3);
		insurancePolicies.add(policy4);

		when(irrp.getAllInsurancePolicies()).thenReturn(insurancePolicies);

		List<InsurancePolicy> result = customerOptionsController.getAllInsurancePolicies(model);

		// Perform assertions on the result and verify interactions
		assertThat(result, is(equalTo(insurancePolicies)));
		verify(model).addAttribute(eq("list"), eq(insurancePolicies));
	}

	@Test
	public void testGetCustomerInsurancePolicy() {
		Integer customerId = 31;
		List<InsurancePolicy> customerInsurancePolicies = new ArrayList<>();
		InsurancePolicy policy1 = new InsurancePolicy();
		InsurancePolicy policy2 = new InsurancePolicy();
		customerInsurancePolicies.add(policy1);
		customerInsurancePolicies.add(policy2);
		customerInsurancePolicies.add(policy1);
		customerInsurancePolicies.add(policy2);

		when(irrp.getCustomerInsurancePolicy(customerId)).thenReturn(customerInsurancePolicies);

		List<InsurancePolicy> result = customerOptionsController.getCustomerInsurancePolicy(model, customerId);

		// Perform assertions on the result and verify interactions
		assertThat(result, is(equalTo(customerInsurancePolicies)));
		verify(model).addAttribute(eq("list"), eq(customerInsurancePolicies));
	}

	@Test
	public void testGetAllFAQS() {
		List<Faq> faqs = new ArrayList<>();
		Faq faq1 = new Faq();
		Faq faq2 = new Faq();
		Faq faq3 = new Faq();
		Faq faq4 = new Faq();
		faqs.add(faq1);
		faqs.add(faq2);
		faqs.add(faq3);
		faqs.add(faq4);

		when(irrp.getAllFAQS()).thenReturn(faqs);

		List<Faq> result = customerOptionsController.getAllFAQS(model);

		// Perform assertions on the result and verify interactions
		assertThat(result, is(equalTo(faqs)));
		verify(model).addAttribute(eq("list"), eq(faqs));
	}

	@Test
	public void testGetGeneralFAQS() {
		List<Faq> generalFaqs = new ArrayList<>();
		Faq faq1 = new Faq();
		Faq faq2 = new Faq();
		generalFaqs.add(faq1);
		generalFaqs.add(faq2);

		when(irrp.getGeneralFAQS()).thenReturn(generalFaqs);

		List<Faq> result = customerOptionsController.getGeneralFAQS(model);

		// Perform assertions on the result and verify interactions
		assertThat(result, is(equalTo(generalFaqs)));
		verify(model).addAttribute(eq("list"), eq(generalFaqs));
	}

	@Test
	public void testGetCoverageandBenefitsFAQS() {
		// Dummy data for coverage and benefits FAQs
		List<Faq> coverageFaqs = new ArrayList<>();
		Faq faq1 = new Faq();
		Faq faq2 = new Faq();
		coverageFaqs.add(faq1);
		coverageFaqs.add(faq2);

		when(irrp.getCoverageandBenefitsFAQS()).thenReturn(coverageFaqs);

		List<Faq> result = customerOptionsController.getCoverageandBenefitsFAQS(model);

		// Perform assertions on the result and verify interactions
		assertThat(result, is(equalTo(coverageFaqs)));
		verify(model).addAttribute(eq("list"), eq(coverageFaqs));
	}

	@Test
	public void testGetInsurancePackages() {
		// Dummy data for insurance packages
		List<InsurancePackages> insurancePackages = new ArrayList<>();
		InsurancePackages package1 = new InsurancePackages();
		InsurancePackages package2 = new InsurancePackages();




		insurancePackages.add(package1);
		insurancePackages.add(package2);

		when(irrp.getInsurancePackages()).thenReturn(insurancePackages);

		List<InsurancePackages> result = customerOptionsController.getInsurancePackages(model);

		// Perform assertions on the result and verify interactions
		assertThat(result, is(equalTo(insurancePackages)));
		verify(model).addAttribute(eq("list"), eq(insurancePackages));
	}

	@Test
	public void testCreateCustomer() {
		// Dummy data for the form data
		FormData formData = new FormData();
		formData.setfName("John");
		formData.setlName("Doe");

		formData.setAddress("Vizag");
		Long customerId = (long) 29;

		when(irrp.addCustomer(formData)).thenReturn(customerId);

		ResponseEntity<Object> responseEntity = customerOptionsController.createBook(formData);

		// Perform assertions on the responseEntity
		assertThat(responseEntity.getStatusCode(), is(HttpStatus.CREATED));
		assertThat(responseEntity.getBody(), is(equalTo(customerId)));
	}
}


