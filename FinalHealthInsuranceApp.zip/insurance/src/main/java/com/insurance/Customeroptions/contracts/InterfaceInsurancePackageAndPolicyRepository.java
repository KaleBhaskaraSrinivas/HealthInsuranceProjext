package com.insurance.Customeroptions.contracts;

import java.util.List;

import com.insurance.Customeroptions.model.Faq;
import com.insurance.Customeroptions.model.FormData;
import com.insurance.Customeroptions.model.InsurancePackages;
import com.insurance.Customeroptions.model.InsurancePolicy;

public interface InterfaceInsurancePackageAndPolicyRepository {

	public List<InsurancePolicy> getAllInsurancePolicies();

	public List<Faq> getAllFAQS();

	public List<InsurancePolicy> getCustomerInsurancePolicy(int cust);

	public List<InsurancePackages> getInsurancePackages();

	public Long addCustomer(FormData loan);

	public List<Faq> getGeneralFAQS();

	public List<Faq> getCoverageandBenefitsFAQS();
}
