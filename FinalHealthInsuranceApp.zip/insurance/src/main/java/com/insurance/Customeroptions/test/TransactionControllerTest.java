package com.insurance.Customeroptions.test;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import com.insurance.Customeroptions.contracts.InterfacePaymentRepository;
import com.insurance.Customeroptions.controller.TransactionController;
import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicyPayment;
import com.insurance.Customeroptions.model.NetworkHospitals;
import com.insurance.Customeroptions.rowmapper.TransactionLimitExceededException;

@RunWith(MockitoJUnitRunner.class)
public class TransactionControllerTest {

	@InjectMocks
	private TransactionController transactionController;

	@Mock
	private InterfacePaymentRepository paymentRepository;

	@Before
	public void setUp() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	public void testCreatePayment() {
		InsurancePolicyPayment payment = new InsurancePolicyPayment();

		when(paymentRepository.insertpayment(payment)).thenReturn(true);

		ResponseEntity<String> responseEntity = transactionController.createPayment(payment);

		assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));
		assertThat(responseEntity.getBody(), is(equalTo("Payment created successfully")));
	}

	@Test
	public void testGetAllipps() {

		List<InsurancePolicyPayment> payments = new ArrayList<>();
		InsurancePolicyPayment payment1 = new InsurancePolicyPayment();

		InsurancePolicyPayment payment2 = new InsurancePolicyPayment();

		payments.add(payment1);
		payments.add(payment2);

		when(paymentRepository.getAllIPPsData()).thenReturn(payments);

		List<InsurancePolicyPayment> result = transactionController.getAllpps();

		assertThat(result, is(equalTo(payments)));
	}

	@Test
	public void testGetAllFirstPP() {
		int policyId = 30;
		List<InsurancePolicyPayment> firstPayments = new ArrayList<>();
		InsurancePolicyPayment payment1 = new InsurancePolicyPayment();

		InsurancePolicyPayment payment2 = new InsurancePolicyPayment();

		firstPayments.add(payment1);
		firstPayments.add(payment2);

		when(paymentRepository.getAllFirstPP(policyId)).thenReturn(firstPayments);

		List<InsurancePolicyPayment> result = transactionController.getAllFirstPP(policyId);

		assertThat(result, is(equalTo(firstPayments)));
	}

	@Test
	public void testGetAlltransactionsbycustid() {
		int customerId = 5;
		List<InsurancePolicyPayment> transactions = new ArrayList<>();
		InsurancePolicyPayment payment1 = new InsurancePolicyPayment();

		InsurancePolicyPayment payment2 = new InsurancePolicyPayment();

		transactions.add(payment1);
		transactions.add(payment2);

		when(paymentRepository.getAllTransactionsbyID(customerId)).thenReturn(transactions);

		List<InsurancePolicyPayment> result = transactionController.getAlltransactionsbycustid(customerId);

		assertThat(result, is(equalTo(transactions)));
	}

	@Test
	public void testInsertCoveragemember() {
		int policyId = 30;

		InsurancePolicyCoverageMembers ipcm = new InsurancePolicyCoverageMembers();

		when(paymentRepository.insertIPCMdata(ipcm, policyId)).thenReturn(true);

		ResponseEntity<String> responseEntity = transactionController.Insert(ipcm, policyId);

		assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));
		assertThat(responseEntity.getBody(), is(equalTo("InsurancePolicyCoverageMember created successfully")));
	}

	@Test
	public void testGetAlldata() {

		List<InsurancePolicyCoverageMembers> members = new ArrayList<>();
		InsurancePolicyCoverageMembers member1 = new InsurancePolicyCoverageMembers();

		InsurancePolicyCoverageMembers member2 = new InsurancePolicyCoverageMembers();

		members.add(member1);
		members.add(member2);

		when(paymentRepository.getAllIpcmData()).thenReturn(members);

		List<InsurancePolicyCoverageMembers> result = transactionController.getAlldata();

		assertThat(result, is(equalTo(members)));
	}

	@Test
	public void testGetAllHospitals() {

		ArrayList<NetworkHospitals> hospitals = new ArrayList<>();
		NetworkHospitals hospital1 = new NetworkHospitals();

		NetworkHospitals hospital2 = new NetworkHospitals();

		hospitals.add(hospital1);

		hospitals.add(hospital2);

		when(paymentRepository.getAllHospitals()).thenReturn(hospitals);

		ArrayList<NetworkHospitals> result = transactionController.getAllHospitals();

		assertThat(result, is(equalTo(hospitals)));
	}

	@Test
	public void testUpdatePaymentRecord() throws ParseException, TransactionLimitExceededException {

		Map<String, String> requestData = new HashMap<>();
		requestData.put("policyId", "30");
		requestData.put("transactionId", "12345");
		requestData.put("transDate", "2023-10-10");

		when(paymentRepository.updateTransactionsId(1, "12345", new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse("2023-10-10").getTime())))
		.thenReturn(true);

		ResponseEntity<String> responseEntity = transactionController.updatePaymentRecord(requestData);

		assertThat(responseEntity.getStatusCode(), is(HttpStatus.OK));
		assertThat(responseEntity.getBody(), is(equalTo("Payment record updated successfully")));
	}

	@Test
	public void testUpdatePaymentRecord_TransactionLimitExceeded() throws ParseException, TransactionLimitExceededException {

		Map<String, String> requestData = new HashMap<>();
		requestData.put("policyId", "30");
		requestData.put("transactionId", "12345");
		requestData.put("transDate", "2023-10-10");

		when(paymentRepository.updateTransactionsId(1, "12345", new java.sql.Date(new SimpleDateFormat("yyyy-MM-dd").parse("2023-10-10").getTime())))
		.thenReturn(false);
		when(paymentRepository.checkTransactionLimitExceeded(1)).thenReturn(true);

		ResponseEntity<String> responseEntity = transactionController.updatePaymentRecord(requestData);

		assertThat(responseEntity.getStatusCode(), is(HttpStatus.BAD_REQUEST));
		assertThat(responseEntity.getBody(), is(equalTo("Your transactions are exceeded.")));
	}

	@Test
	public void testUpdatePaymentRecord_InvalidPolicyId() throws TransactionLimitExceededException, ParseException {
		Map<String, String> requestData = new HashMap<>();
		requestData.put("policyId", "invalid");
		requestData.put("transactionId", "12345");
		requestData.put("transDate", "2023-10-10");

		ResponseEntity<String> responseEntity = transactionController.updatePaymentRecord(requestData);

		assertThat(responseEntity.getStatusCode(), is(HttpStatus.BAD_REQUEST));
		assertThat(responseEntity.getBody(), is(equalTo("Invalid policyId provided.")));
	}
}


