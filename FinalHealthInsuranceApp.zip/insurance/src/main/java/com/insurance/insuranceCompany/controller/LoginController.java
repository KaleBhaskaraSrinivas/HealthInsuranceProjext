package com.insurance.insuranceCompany.controller;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.model.OTPclass;
import com.insurance.insuranceCompany.service.HospitalLoginService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/insurance")
public class LoginController {

	HospitalLoginService logService;
	HttpSession session;
	private final Logger logger;

	@Autowired
	public LoginController(HospitalLoginService rep, HttpSession session, Logger loginControllerLogger) {
		this.logService = rep;
		this.session = session;
		this.logger = loginControllerLogger;
	}

	// for the login page
	@GetMapping({ "/login", "insurancelogin", "/" })
	public String loginPage(Model model) {
		try {
			logger.trace("Entering loginPage method");
			session.setAttribute("login", 0);
			model.addAttribute("login", new Login());
			logger.info("Redirected to login page");
			return "loginPage";
		} catch (Exception e) {
			logger.error("An error occurred in loginPage", e);
			return "loginPage";
		} finally {
			logger.trace("Exiting loginPage method");
		}
	}

	// for login form submission
	@PostMapping("/login")
	public String loginSubmit(@ModelAttribute("login") Login lc, Model model) {
		try {
			logger.trace("Entering loginSubmit method");
			logger.info("Received login request with credentials: {}", lc);

			Login check = logService.checkCredentials(lc);
			logger.info("Login check result: {}", check);

			if (check != null) {
				session.setAttribute("login", check.getRoleid());
				logger.info("Login successful. Redirecting to dashboard.");
				return "dashboard";
			}

			model.addAttribute("login", new Login());
			model.addAttribute("errorMessage", "incorrect credentials");
			logger.info("Login failed. Redirecting back to login page.");
			return "loginPage";
		} catch (Exception e) {
			logger.error("An error occurred in loginSubmit", e);
			return "loginPage";
		} finally {
			logger.trace("Exiting loginSubmit method");
		}
	}

	// for the dashboard
	@GetMapping("/dashboard")
	public String dashboard(Model model) {
		logger.trace("Entering dashboard method");
		Object lc = session.getAttribute("login");

		if (lc == null || (int) lc == 0) {
			model.addAttribute("noaccess", "you need to login first");
			model.addAttribute("login", new Login());
			logger.info("Access denied. Redirecting to loginPage.");
			return "loginPage";
		}

		logger.info("Access granted. Redirecting to dashboard.");
		return "dashboard";
	}

	// for the forgot password page
	@GetMapping("/forgotpassword")
	public String forgotpassword(Model model) {
		try {
			logger.trace("Entering forgotpassword method");
			model.addAttribute("to", "");
			model.addAttribute("login", new OTPclass());
			logger.info("Redirecting to forgotPasswordPage.");
			return "forgotPasswordPage";
		} catch (Exception e) {
			logger.error("An error occurred in forgotpassword", e);
			return "dashboard"; // or any other appropriate view
		} finally {
			logger.trace("Exiting forgotpassword method");
		}
	}

	// to sign out the user
	@GetMapping("/signout")
	public String signout(Model model) {
		try {
			logger.trace("Entering signout method");
			session.setAttribute("login", 0);
			model.addAttribute("login", new Login());
			logger.info("User has been signed out.");
			return "loginPage";
		} catch (Exception e) {
			logger.error("An error occurred in signout", e);
			return "dashboard"; // or any other appropriate view
		} finally {
			logger.trace("Exiting signout method");
		}
	}
}
