package com.insurance.insuranceCompany.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.insuranceCompany.contract.ClaimServiceContract;
import com.insurance.insuranceCompany.contract.ClaimsContract;
import com.insurance.insuranceCompany.model.CB;
import com.insurance.insuranceCompany.model.Claim;
import com.insurance.insuranceCompany.model.ClaimApplication;
import com.insurance.insuranceCompany.model.ClaimBills;
import com.insurance.insuranceCompany.model.ClaimHistory;
import com.insurance.insuranceCompany.model.CoveredDiseases;
import com.insurance.insuranceCompany.model.ReUpload;
import com.insurance.insuranceCompany.model.Uploads;

@Service
public class HospitalClaimService implements ClaimServiceContract {
	@Autowired
	ClaimsContract cdao;

	@Override
	public ArrayList<Claim> getAllClaims() {
		return (ArrayList<Claim>) cdao.getAllClaims();
	}

	@Override
	public ArrayList<Claim> getFilteredClaims(String status) {
		return (ArrayList<Claim>) cdao.getFilteredClaims(status);
	}

	@Override
	public Claim getClaimById(int clamId) {
		return cdao.getClaimById(clamId);
	}

	@Override
	public void addClaim(int i, double requestAmount, String hospname) {
		cdao.setClaim(i, requestAmount, hospname);

	}

	@Override
	public Claim getClaimByid(int clamIplcId) {
		return cdao.getClaimByid(clamIplcId);
	}

	@Override
	public void addClaimBills(String f, String filePath, int cid, int amt) {
		cdao.setDocs(f, filePath, cid, amt);
	}

	@Override
	public ArrayList<ClaimBills> viewClaimDocsById(int clamId) {
		return cdao.getDocs(clamId);
	}

	// Insurance------------

	@Override
	public ArrayList<Claim> viewAllClaims() {
		return (ArrayList<Claim>) cdao.viewAllClaims();
	}

	@Override
	public Claim viewClaimById(int clamId) {
		return cdao.viewClaimById(clamId);
	}

	@Override
	public int editClaimById(int clamId, String clamRemarks, String clamStatus) {
		return cdao.editClaimById(clamId, clamRemarks, clamStatus);
	}

	@Override
	public ClaimBills viewdocBills(int billIndex, int cid) {
		return cdao.getDocBills(billIndex, cid);
	}

	@Override
	public void addClaimApplication(ClaimApplication application) {
		cdao.addClaimApplication(application);

	}

	@Override
	public List<ClaimApplication> getAllApplicantions() {

		return cdao.getAllApplications();
	}

	@Override
	public Claim getCliamByPolicy(int id) {

		return cdao.getClaimByPolicy(id);
	}

	@Override
	public void updateClaimBill(CB bill, int cid) {

		cdao.updateClaimBill(bill, cid);

	}

	@Override
	public List<CoveredDiseases> getAllDiseasesCovered(int id) {

		return cdao.getAllCoveredDiseases(id);
	}

	@Override
	public void editClaimById(int clamId, String clamRemarks, String clamStatus, String clamProcessedAmount) {

		cdao.updateClaimBill(clamId, clamRemarks, clamStatus, clamProcessedAmount);
	}

	@Override
	public void updateClaimDate(int clamId) {
		cdao.updateDate(clamId);

	}

	@Override
	public ClaimBills updatedate(int billIndex) {
		return cdao.updt(billIndex);

	}

	@Override
	public List<ClaimHistory> getHistory(int cid) {
		return cdao.getHistory(cid);
	}

	@Override
	public void addRequiredUpload(ReUpload upload) {
		cdao.addRequiredUploads(upload);
	}

	@Override
	public List<ReUpload> getAllReUploads(int id) {
		return cdao.getAllReUploads(id);
	}

	@Override
	public void addUploads(Uploads up) {
		cdao.addUploads(up);

	}

	@Override
	public List<Uploads> getFlow(int id) {
		return cdao.getFlow(id);
	}

	@Override
	public Boolean checkRequestedAmount(int pid, double requestedClaimAmount) {
		return cdao.checkRequestedAmount(pid, requestedClaimAmount);
	}

}