package com.insurance.insuranceCompany.controller;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.repository.PaymentService;
import com.insurance.insuranceCompany.repository.SettlementRepository;
import com.insurance.insuranceCompany.service.HospitalLoginService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/insurance")
public class PaymentController {

	PaymentService ps;
	HttpSession session;
	HospitalLoginService perrep;
	private final Logger logger;

	@Autowired
	public PaymentController(SettlementRepository clr, HttpSession session, HospitalLoginService perrep,
			PaymentService ps, Logger paymentControllerLogger) {
		this.session = session;
		this.perrep = perrep;
		this.ps = ps;
		this.logger = paymentControllerLogger;

	}

	// to retrieve all payments
	@GetMapping(value = "/getPayments")
	public String getAllTransaction(Model model) {
		try {
			logger.trace("Entering getAllTransaction method");

			// Check if the user is logged in
			Object lc = session.getAttribute("login");
			if (lc == null || (int) lc == 0) {
				model.addAttribute("noaccess", "you need to log in first");
				model.addAttribute("login", new Login());
				return "loginPage";
			}

			// Check user access rights
			int access = perrep.checkAccess((int) lc, "/getPayments");
			if (access == 1) {
				// Retrieve all payment transactions
				model.addAttribute("payments", ps.getAllTransaction());
				logger.info("Retrieved all payments successfully.");
				return "ViewPayments";
			} else {
				// User doesn't have access to the payment section
				model.addAttribute("noaccess", "you don't have access to the payment section");
				logger.warn("Access denied for /getPayments");
				return "dashboard";
			}
		} catch (Exception e) {
			logger.error("An error occurred in getAllTransaction", e);
			return "ViewPayments"; // Return the ViewPayments page even if there's an error
		} finally {
			logger.trace("Exiting getAllTransaction method");
		}
	}
}
