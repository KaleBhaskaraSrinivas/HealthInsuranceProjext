package com.insurance.insuranceCompany.controller;

import java.io.IOException;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/insurance")
public class FileController {

	private static final String FILE_DIRECTORY = "C:\\Users\\Hemu\\Downloads\\chaiKiran-main (1)\\chaiKiran-main\\insuranceCompany\\insuranceCompany\\src\\main\\resources\\static\\file"; // Set
																																															// the
																																															// path
																																															// to
																																															// your
																																															// files

	@GetMapping("/file/{fileName}")
	public ResponseEntity<Resource> serveFile(@PathVariable String fileName) {
		try {
			Path filePath = Paths.get(FILE_DIRECTORY, fileName);
			Resource resource = new UrlResource(filePath.toUri());

			if (resource.exists() && resource.isReadable()) {
				HttpHeaders headers = new HttpHeaders();
				headers.add(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=" + fileName);
				headers.setContentType(MediaType.APPLICATION_PDF); // Set the appropriate content type

				return ResponseEntity.ok().headers(headers).body(resource);
			} else {
				// Handle the case when the file doesn't exist or is not readable
				return ResponseEntity.notFound().build();
			}
		} catch (IOException e) {
			// Handle exceptions if any
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
		}
	}
}
