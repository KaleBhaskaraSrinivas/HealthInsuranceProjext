package com.insurance.insuranceCompany.controller;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.contract.CustomerRepositoryInterface;

@Controller
@RequestMapping("/insurance")
public class CustomerController {

    @Autowired
    CustomerRepositoryInterface cri;
    
    @Autowired
    HttpSession session;

    // Initialize a logger for this controller
    private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);

    // Handle GET request to retrieve a list of customers
    @GetMapping("/getCustomers")
    public String getCustomers(Model model) {
        try {
            logger.trace("Entering getCustomers method");

            // Check if the user is logged in, if not, redirect to the login page
            Object lc = session.getAttribute("login");
            if (lc == null || (int) lc == 0) {
                model.addAttribute("noaccess", "you need to login first");
                model.addAttribute("login", new Login());
                return "loginPage";
            }

            // Get a list of customers and add it to the model
            model.addAttribute("customers", cri.getAllCustomers());

            logger.info("Retrieved customer list successfully");

            // Return the view for displaying the customer list
            return "customerList";
        } catch (Exception e) {
            logger.error("An error occurred in getCustomers", e);
            // You can add a message to the model indicating the error, or simply continue without showing an error message.
            return "customerList"; // Return the customer list view to display available data.
        } finally {
            logger.trace("Exiting getCustomers method");
        }
    }

    // Handle GET request to retrieve details of a specific customer
    @GetMapping("/getCustomerDetails")
    public String getCustomerDetails(@RequestParam("IdVal") String Id, Model model) {
        try {
            logger.trace("Entering getCustomerDetails method");

            // Get customer details and policies for the specified customer ID
            model.addAttribute("customer", cri.getCustomerId(Integer.parseInt(Id)));
            model.addAttribute("policies", cri.getPolicies(Id));

            logger.info("Retrieved customer details successfully");

            // Return the view for displaying customer details
            return "customerDetails";
        } catch (Exception e) {
            logger.error("An error occurred in getCustomerDetails", e);
            // You can add a message to the model indicating the error, or simply continue without showing an error message.
            return "customerDetails"; // Return the customer details view to display available data.
        } finally {
            logger.trace("Exiting getCustomerDetails method");
        }
    }

    // Handle POST request to update customer status
    @PostMapping("/updateCStatus")
    @ResponseBody
    public String updateStatus(@RequestParam String Id, String Status) {
        try {
            logger.trace("Entering updateStatus method");

            // Update the customer status and get a message indicating success or failure
            String message = cri.updateStatus(Integer.parseInt(Id), Status);

            logger.info("Customer status updated successfully");

            // Return the update status message as a response
            return message;
        } catch (Exception e) {
            logger.error("An error occurred in updateStatus", e);
            // You can return an appropriate error message if needed.
            return "Error occurred while updating customer status";
        } finally {
            logger.trace("Exiting updateStatus method");
        }
    }
}
