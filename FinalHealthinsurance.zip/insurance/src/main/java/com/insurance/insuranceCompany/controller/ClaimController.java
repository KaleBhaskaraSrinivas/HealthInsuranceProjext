package com.insurance.insuranceCompany.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.insurance.insuranceCompany.contract.ClaimServiceContract;
import com.insurance.insuranceCompany.model.CB;
import com.insurance.insuranceCompany.model.Claim;
import com.insurance.insuranceCompany.model.ClaimBills;
import com.insurance.insuranceCompany.model.ClaimHistory;
import com.insurance.insuranceCompany.model.CoveredDiseases;
import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.model.ReUpload;
import com.insurance.insuranceCompany.model.Uploads;
import com.insurance.insuranceCompany.repository.NetworkHospitalRepository;
import com.insurance.insuranceCompany.repository.PackagesRepository;
import com.insurance.insuranceCompany.repository.SettlementRepository;
import com.insurance.insuranceCompany.service.HospitalLoginService;

import jakarta.servlet.ServletContext;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/insurance")
public class ClaimController {
	@Autowired
	ClaimServiceContract insuranceService;
	private static final Logger logger = LoggerFactory.getLogger(ClaimController.class);
	HospitalLoginService perrep;
	HttpSession session;
	SettlementRepository clr;
	NetworkHospitalRepository nhr;
	PackagesRepository pr;

	@Autowired
	public ClaimController(SettlementRepository clr, NetworkHospitalRepository nhr, PackagesRepository pr,
			HttpSession session, HospitalLoginService perrep) {
		this.clr = clr;
		this.nhr = nhr;
		this.pr = pr;
		this.session = session;
		this.perrep = perrep;
	}

	@PostMapping(value = "/viewdocs")
	public String viewDocs(Model model, @RequestParam("clamId") int clamId) {
		try {
			logger.trace("Entering viewDocs method");

			ArrayList<ClaimBills> cl = insuranceService.viewClaimDocsById(clamId);
			System.out.println(cl.size() + "brooo");

			model.addAttribute("claim", cl);

			return "ViewClaimDocuments";
		} catch (Exception e) {
			// You can handle the error and return an appropriate response or redirect to an error page.
			return "ViewClaimDocuments"; // Replace "errorPage" with the actual error page name.
		} finally {
			logger.trace("Exiting viewDocs method");
		}
	}

	@GetMapping(value = "/viewClaims")
	public String viewAllClaims(Model model) {
		try {
			logger.trace("Entering viewAllClaims method");
			logger.info("Fetching all insurance claims");

			ArrayList<Claim> li = (ArrayList<Claim>) insuranceService.viewAllClaims();
			System.out.println(li.size());

			model.addAttribute("claims", li);

			logger.info("Fetched {} insurance claims", li.size());

			return "InsuClaims";
		} catch (Exception e) {
			logger.error("An error occurred while fetching all insurance claims", e);
			// You can handle the error and return an appropriate response or redirect to an error page.
			return "InsuClaims"; // Replace "errorPage" with the actual error page name.
		} finally {
			logger.trace("Exiting viewAllClaims method");
		}
	}

	@PostMapping(value = "/viewInsuClaim")
	public String viewClaimById(Model model, @RequestParam("clamId") int clamId) {
		try {
			logger.trace("Entering viewClaimById method");
			logger.info("Fetching insurance claim by ID: {}", clamId);

			Claim cl = insuranceService.viewClaimById(clamId);

			model.addAttribute("claim", cl);

			logger.info("Fetched insurance claim by ID: {}", clamId);

			return "viewInsuclaim";
		} catch (Exception e) {
			logger.error("An error occurred while fetching insurance claim by ID: {}", clamId, e);
			// You can handle the error and return an appropriate response or redirect to an error page.
			return "viewInsuclaim"; // Replace "errorPage" with the actual error page name.
		} finally {
			logger.trace("Exiting viewClaimById method");
		}
	}

	@PostMapping(value = "/processClaim")
	public String editClaimById(Model model, @RequestParam("clamId") int clamId,
			@RequestParam("clamRemarks") String clamRemarks,
			@RequestParam("clamProcessedAmount") String clamProcessedAmount,
			@RequestParam("clamStatus") String clamStatus) {
		try {
			logger.trace("Entering editClaimById method");
			logger.info("Editing insurance claim by ID: {}", clamId);

			insuranceService.editClaimById(clamId, clamRemarks, clamStatus, clamProcessedAmount);

			Claim claim = insuranceService.viewClaimById(clamId);
			model.addAttribute("claim", claim);

			logger.info("Edited insurance claim by ID: {}", clamId);

			return "viewclaim";
		} catch (Exception e) {
			logger.error("An error occurred while editing insurance claim by ID: {}", clamId, e);
			// You can handle the error and return an appropriate response or redirect to an error page.
			return "viewclaim"; // Replace "errorPage" with the actual error page name.
		} finally {
			logger.trace("Exiting editClaimById method");
		}
	}

	@GetMapping(value = "/docbills")
	public String viewdocBills(@RequestParam("clbl_billindex") int billIndex, Model model) {
		try {
			logger.trace("Entering viewdocBills method");
			logger.info("Viewing document bills for bill index: {}", billIndex);

			ClaimBills li = insuranceService.viewdocBills(billIndex);
			ClaimBills cc = insuranceService.updatedate(li.getBillIndex());
			System.out.println(li.getBillIndex() + "hiiii");
			model.addAttribute("date", cc.getProcessedDate());
			/* insuranceService.updateClaimDate(billIndex); */
			model.addAttribute("claim", li);

			logger.info("Viewed document bills for bill index: {}", billIndex);

			return "viewSingleDocs";
		} catch (Exception e) {
			logger.error("An error occurred while viewing document bills for bill index: {}", billIndex, e);
			// You can handle the error and return an appropriate response or redirect to an error page.
			return "viewSingleDocs"; // Replace "errorPage" with the actual error page name.
		} finally {
			logger.trace("Exiting viewdocBills method");
		}
	}

	@GetMapping(value = "/allclaimbills")
	public String viewClaimBills(@RequestParam("claimid") int id, Model model) {
		try {
			logger.trace("Entering viewClaimBills method");
			logger.info("Viewing claim bills for claim ID: {}", id);

			List<ClaimBills> lc = insuranceService.viewClaimDocsById(id);
			model.addAttribute("claimBills", lc);

			if (!lc.isEmpty()) {
				int claimId = lc.get(0).getClaimId();
				model.addAttribute("lc", claimId);
			}

			return "claimbills";
		} catch (Exception e) {
			logger.error("An error occurred while viewing claim bills for claim ID: {}", id, e);
			// You can handle the error and return an appropriate response or redirect to an error page.
			return "claimbills"; // Replace "errorPage" with the actual error page name.
		} finally {
			logger.trace("Exiting viewClaimBills method");
		}
	}

	@GetMapping(value = "/applications")
	public String getApplications(Model model) {
		try {
			logger.trace("Entering getApplications method");

			Object lc = session.getAttribute("login");

			if (lc == null || (int) lc == 0) {
				model.addAttribute("noaccess", "you need to login first");
				model.addAttribute("login", new Login());
				logger.info("User attempted to access applications without logging in");
				return "loginPage";
			}

			int access = perrep.checkAccess((int) lc, "/applications");

			if (access == 1) {
				model.addAttribute("claimApplications", insuranceService.getAllApplicantions());
				logger.info("User successfully accessed applications");
				return "applications";
			}

			model.addAttribute("noaccess", "you dont have access to the claims section");
			model.addAttribute("hospitalCount", nhr.getHospitalsCount());
			model.addAttribute("packageCount", pr.getPackagesCount());
			logger.info("User attempted to access applications but doesn't have access");
			return "dashboard";
		} catch (Exception e) {
			logger.error("An error occurred in getApplications method", e);
			// You can handle the error and return an appropriate response or redirect to an error page.
			return "dashboard"; // Replace "errorPage" with the actual error page name.
		} finally {
			logger.trace("Exiting getApplications method");
		}
	}

	@GetMapping(value = "/getClaim")
	public String getClaim(@RequestParam("policy") int id, Model model) {
		Claim claim = insuranceService.getCliamByPolicy(id);
		insuranceService.updateClaimDate(claim.getClamId());
		System.out.println(claim.toString());
		model.addAttribute("claim", claim);
		return "viewclaim";
	}

	@GetMapping(value = "/getDiseases")
	public String getCoveredDiseases(@RequestParam("policy") int id, Model model) {

		List<CoveredDiseases> ls = insuranceService.getAllDiseasesCovered(id);
		model.addAttribute("diseases", ls);

		return "diseasescovered";
	}

	@RequestMapping(value = "/downloadZip", method = RequestMethod.GET)
	public String downloadZipFromDatabase(HttpServletResponse response, @RequestParam("clamId") int clamId,
			ServletContext servletContext) {
		// Create some temporary file paths for demonstration purposes
		System.out.println("mad");
		ArrayList<ClaimBills> cl = insuranceService.viewClaimDocsById(clamId);
		System.out.println(cl.size());
		List<String> filePathsFromDatabase = new ArrayList<>();
		for (ClaimBills cb : cl) {
			// Use getResourceAsStream to obtain an InputStream to the resource
			InputStream inputStream = servletContext.getResourceAsStream("/WEB-INF/static/" + cb.getDocumentPath());
			if (inputStream != null) {
				try {
					// Create a temporary file and write the content of the resource into it
					File tempFile = File.createTempFile("downloadedFile", null);
					try (FileOutputStream outputStream = new FileOutputStream(tempFile)) {
						byte[] buffer = new byte[1024];
						int bytesRead;
						while ((bytesRead = inputStream.read(buffer)) != -1) {
							outputStream.write(buffer, 0, bytesRead);
						}
					}
					System.out.println(tempFile.getAbsolutePath() + "     checking path");
					filePathsFromDatabase.add(tempFile.getAbsolutePath());
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}

		if (filePathsFromDatabase.isEmpty()) {
			response.setStatus(HttpServletResponse.SC_NOT_FOUND);
		}
		try {
			Path tempDir = Files.createTempDirectory("downloadedFiles");

			for (String filePath : filePathsFromDatabase) {
				Path sourcePath = Paths.get(filePath);
				Path targetPath = tempDir.resolve(sourcePath.getFileName());
				Files.copy(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
			}

			String zipFileName = "downloadedFiles.zip";
			response.setContentType("application/zip");
			response.setHeader("Content-Disposition", "attachment; filename=\"" + zipFileName + "\"");

			try (ZipOutputStream zipOutputStream = new ZipOutputStream(response.getOutputStream())) {
				Files.walk(tempDir).filter(Files::isRegularFile).forEach(file -> {
					try {
						String entryName = tempDir.relativize(file).toString();
						ZipEntry zipEntry = new ZipEntry(entryName);
						zipOutputStream.putNextEntry(zipEntry);
						Files.copy(file, zipOutputStream);
						zipOutputStream.closeEntry();
					} catch (IOException e) {
						e.printStackTrace();
					}
				});
			}

			Files.walk(tempDir).sorted(Comparator.reverseOrder()).map(Path::toFile).forEach(File::delete);

		} catch (IOException ex) {
			ex.printStackTrace();
			response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
		}
		return "flow";
	}

	@PostMapping(value = "/updateClaimBill")
	public String updateClaimBill(Model model, CB bill, @RequestParam("claimid") String cid) {

		System.out.println(bill.getBillIndex() + "  1000 " + cid);
		System.out.println(bill.getProcessedAmount());
		System.out.println(bill.getRemarks());
		System.out.println(bill.getStatus() + "  1000");
		insuranceService.updateClaimBill(bill, Integer.parseInt(cid));
		model.addAttribute("claim", insuranceService.viewdocBills(bill.getBillIndex()));
		return "viewSingleDocs";
	}

	@GetMapping(value = "/allrecords")
	public String getHistory(@RequestParam("claimid") int cid, Model model) {
		List<ClaimHistory> m = insuranceService.getHistory(cid);

		model.addAttribute("claimhistory", m);
		return "history";

	}

	@GetMapping(value = "/moredocuments")
	public String moreDocuments(@RequestParam("claimid") int id, Model model) {

		model.addAttribute("claimid", id);
		return "moredocuments";
	}

	@GetMapping(value = "/addRequiredUpload")
	public String reuploadDocuments(@RequestParam("claimid") int claimId, @RequestParam("name") String[] fileNames,
			@RequestParam("type") String[] fileTypes, @RequestParam("remarks") String[] fileRemarks, Model model) {
		try {
			logger.trace("Entering reuploadDocuments method");
			logger.info("Uploading required documents for claim ID: {}", claimId);

			for (int i = 0; i < fileNames.length; i++) {
				ReUpload upload = new ReUpload();
				upload.setClaimId(claimId);
				upload.setName(fileNames[i]);
				upload.setType(fileTypes[i]);
				upload.setDescription(fileRemarks[i]);
				insuranceService.addRequiredUpload(upload);
			}

			logger.info("Uploaded required documents for claim ID: {}", claimId);

			model.addAttribute("claimid", claimId);

			return "moredocuments";
		} catch (Exception e) {
			logger.error("An error occurred while uploading required documents for claim ID: {}", claimId, e);
			// You can handle the error and return an appropriate response or redirect to an error page.
			return "moredocuments"; // Replace "errorPage" with the actual error page name.
		} finally {
			logger.trace("Exiting reuploadDocuments method");
		}
	}

	@GetMapping(value = "/getrequired")
	public String getRequiredUploads(@RequestParam("claimid") int id, Model model) {
		try {
			logger.trace("Entering getRequiredUploads method");
			logger.info("Fetching required uploads for claim ID: {}", id);

			model.addAttribute("reupload", insuranceService.getAllReUploads(id));
			model.addAttribute("claimid", id);

			logger.info("Fetched required uploads for claim ID: {}", id);

			return "update";
		} catch (Exception e) {
			logger.error("An error occurred while fetching required uploads for claim ID: {}", id, e);
			// You can handle the error and return an appropriate response or redirect to an error page.
			return "update"; // Replace "errorPage" with the actual error page name.
		} finally {
			logger.trace("Exiting getRequiredUploads method");
		}
	}

	int index = 1;

	@PostMapping(value = "/adduploads")
	public String addUploads(@RequestParam("claimid") String id, MultipartHttpServletRequest request) {

		int claimId = Integer.parseInt(id);
		System.out.println(claimId);

		List<ReUpload> list = insuranceService.getAllReUploads(claimId);
		for (ReUpload upload : list) {
			if (upload.getClaimId() == claimId) {
				String name = upload.getName();
				System.out.println(claimId);
				MultipartFile file = request.getFile(name);
				if (file != null && !file.isEmpty()) {
					System.out.println(name);
					if (upload.getType().equals("file")) {
						System.out.println("file");

						String uploadDir = "src/main/resources/static/file";
						try {
							Files.createDirectories(Paths.get(uploadDir));

							String fileName = StringUtils.cleanPath(file.getOriginalFilename());
							Path targetLocation = Paths.get(uploadDir).resolve(fileName);
							Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
							String fullPath = targetLocation.toAbsolutePath().toString();

							Uploads up = new Uploads();
							up.setUploadId(index);
							up.setReUploadId(upload.getUploadId());
							up.setClaimId(claimId);
							up.setData(fileName);
							up.setType("file");

							insuranceService.addUploads(up);

						} catch (IOException ex) {
							ex.printStackTrace();
						}
					} else {
						System.out.println("text");

						Uploads up = new Uploads();

						up.setUploadId(index);
						up.setReUploadId(upload.getUploadId());
						up.setClaimId(claimId);
						up.setData(file.getOriginalFilename());
						up.setType("text");

						insuranceService.addUploads(up);
					}
				}
			}
		}

		return "upda";
	}

	@GetMapping(value = "/allrecord")
	@ResponseBody
	public List<ReUpload> allrecord(@RequestParam("claimid") int id, Model model) {
		try {
			logger.trace("Entering allrecord method");
			logger.info("Fetching uploads and re-uploads for claim ID: {}", id);

			List<Uploads> up = insuranceService.getFlow(id);
			List<ReUpload> rup = insuranceService.getAllReUploads(id);

			model.addAttribute("up", up);
			model.addAttribute("rup", rup);

			logger.info("Fetched {} uploads and {} re-uploads for claim ID: {}", up.size(), rup.size(), id);

			return rup;
		} catch (Exception e) {
			logger.error("An error occurred while fetching uploads and re-uploads for claim ID: {}", id, e);
			// You can handle the error and return an appropriate response, e.g., an empty list or an error message.
			return new ArrayList<>();
		} finally {
			logger.trace("Exiting allrecord method");
		}
	}

	@GetMapping(value = "/all")
	public String all(@RequestParam("claimid") int id, Model model) {
		try {
			logger.trace("Entering all method");
			logger.info("Fetching uploads and re-uploads for claim ID: {}", id);

			List<Uploads> up = insuranceService.getFlow(id);
			List<ReUpload> rup = insuranceService.getAllReUploads(id);
			List<Integer> l = new ArrayList<Integer>();
			for (int i = 1; i <= rup.size(); i++) {
				l.add(i);
			}

			model.addAttribute("ind", l);
			model.addAttribute("up", up);
			model.addAttribute("rup", rup);

			logger.info("Fetched {} uploads and {} re-uploads for claim ID: {}", up.size(), rup.size(), id);

			return "flow";
		} catch (Exception e) {
			logger.error("An error occurred while fetching uploads and re-uploads ");
			// Redirect to a fallback page or URL
			return "flow"; // Replace with the appropriate URL or fallback page
		} finally {
			logger.trace("Exiting all method");
		}
	}

	@GetMapping(value = "/goup")
	public String gouup(@RequestParam("cid") int id, Model model) {
		try {
			logger.trace("Entering gouup method");
			logger.info("Fetching uploads and re-uploads for claim ID: {}", id);

			List<Uploads> up = insuranceService.getFlow(id);
			List<ReUpload> rup = insuranceService.getAllReUploads(id);

			model.addAttribute("up", up);
			model.addAttribute("rup", rup);

			logger.info("Fetched {} uploads and {} re-uploads for claim ID: {}", up.size(), rup.size(), id);

			return "upd";
		} catch (Exception e) {
			logger.error("An error occurred while fetching uploads and re-uploads for claim ID: {}", id, e);
			// You can handle the error and return an appropriate view or message
			return "upd"; // Replace with the appropriate view name or error handling logic
		} finally {
			logger.trace("Exiting gouup method");
		}
	}

}