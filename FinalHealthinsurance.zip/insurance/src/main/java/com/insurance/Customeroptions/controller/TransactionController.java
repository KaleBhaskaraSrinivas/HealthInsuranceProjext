package com.insurance.Customeroptions.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.insurance.Customeroptions.contracts.InterfacePaymentRepository;
import com.insurance.Customeroptions.model.ErrorResponse;
import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicyPayment;
import com.insurance.Customeroptions.model.NetworkHospitals;
import com.insurance.Customeroptions.rowmapper.TransactionLimitExceededException;

@RestController
@RequestMapping("/customer")
public class TransactionController {
	private static final Logger logger = LoggerFactory.getLogger(TransactionController.class);

	@Autowired
	InterfacePaymentRepository paymentres;
	// Create a new payment record
	// Create a new payment record
	@PostMapping("/create")
	public ResponseEntity<String> createPayment(@RequestBody InsurancePolicyPayment payment) {
		try {
			boolean result = paymentres.insertpayment(payment);
			if (result) {
				logger.info("Payment created successfully");
				return ResponseEntity.ok("Payment created successfully");
			} else {
				logger.error("Failed to create payment");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create payment");
			}
		} catch (Exception e) {
			logger.error("Failed to create payment", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create payment");
		}
	}

	// Get all insurance policy payments
	@GetMapping(value = "/ipps")
	public List<InsurancePolicyPayment> getAllpps() {
		try {
			List<InsurancePolicyPayment> hosp = paymentres.getAllIPPsData();
			logger.info("Retrieved all insurance policy payments successfully");
			return hosp;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving insurance policy payments", e);
			throw e; // rethrow the exception
		}
	}

	// Get all first insurance policy payments by policy ID
	@GetMapping(value = "/ipps/{iplc_id}")
	public List<InsurancePolicyPayment> getAllFirstPP(@PathVariable int iplc_id) {
		try {
			List<InsurancePolicyPayment> hosp = paymentres.getAllFirstPP(iplc_id);
			logger.info("Retrieved all first insurance policy payments by policy ID: " + iplc_id + " successfully");
			return hosp;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving first insurance policy payments by policy ID: " + iplc_id, e);
			throw e; // rethrow the exception
		}
	}

	// Get all transactions by customer ID
	@GetMapping(value = "/ippsts/{cust_id}")
	public List<InsurancePolicyPayment> getAlltransactionsbycustid(@PathVariable int cust_id) {
		try {
			List<InsurancePolicyPayment> hosp = paymentres.getAllTransactionsbyID(cust_id);
			logger.info("Retrieved all transactions by customer ID: " + cust_id + " successfully");
			return hosp;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving transactions by customer ID: " + cust_id, e);
			throw e; // rethrow the exception
		}
	}

	// Insert insurance policy coverage member data
	@PostMapping("/insertipcm/{policyid}")
	public ResponseEntity<String> Insert(@RequestBody InsurancePolicyCoverageMembers ipcm, @PathVariable int policyid) {
		try {
			boolean result = paymentres.insertIPCMdata(ipcm, policyid);
			if (result) {
				logger.info("InsurancePolicyCoverageMember created successfully");
				return ResponseEntity.ok("InsurancePolicyCoverageMember created successfully");
			} else {
				logger.error("Failed to create member");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create member");
			}
		} catch (Exception e) {
			logger.error("Failed to create member", e);
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to create member");
		}
	}

	// Get all insurance policy coverage members data
	@GetMapping(value = "/ipcmsdata")
	public List<InsurancePolicyCoverageMembers> getAlldata() {
		try {
			List<InsurancePolicyCoverageMembers> hosp = paymentres.getAllIpcmData();
			logger.info("Retrieved all insurance policy coverage members data successfully");
			return hosp;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving insurance policy coverage members data", e);
			throw e; // rethrow the exception
		}
	}

	// Get all network hospitals as JSON
	@GetMapping("/jsonhsp")
	public ArrayList<NetworkHospitals> getAllHospitals() {
		try {
			ArrayList<NetworkHospitals> hospitals = paymentres.getAllHospitals();
			logger.info("Retrieved all network hospitals successfully");
			return hospitals;
		} catch (Exception e) {
			logger.error("Error occurred while retrieving network hospitals", e);
			throw e; // rethrow the exception
		}
	}


	// Update a payment record with transaction details
	@PostMapping("/updatePayment")
	public ResponseEntity<String> updatePaymentRecord(@RequestBody Map<String, String> requestData)
			throws ParseException, TransactionLimitExceededException {
		System.out.println(requestData);
		String policyIdStr = requestData.get("policyId");
		String transactionId = requestData.get("transactionId");
		String transDateStr = requestData.get("transDate");
		if (transDateStr == null || transDateStr.isEmpty()) {
			return ResponseEntity.badRequest().body("currentDate is missing or empty.");
		}

		try {
			int policyId = Integer.parseInt(policyIdStr);

			// Parse currentDateStr into a Date object (assuming it's in ISO format)
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			java.util.Date transDate = dateFormat.parse(transDateStr);

			// Convert java.util.Date to java.sql.Date
			java.sql.Date sqlTransDate = new java.sql.Date(transDate.getTime());

			// Call the updateTransactionId method from the repository with java.sql.Date
			boolean updateSuccess = paymentres.updateTransactionsId(policyId, transactionId, sqlTransDate);

			if (updateSuccess) {
				return ResponseEntity.ok("Payment record updated successfully.");
			} else {
				// Define and set the transactionLimitExceeded variable based on your logic
				boolean transactionLimitExceeded = paymentres.checkTransactionLimitExceeded(policyId);

				if (transactionLimitExceeded) {
					throw new TransactionLimitExceededException("Your transactions are excedded.");
				} else {
					return ResponseEntity.badRequest().body("Payment successful");
				}
			}
		} catch (NumberFormatException e) {
			return ResponseEntity.badRequest().body("Invalid policyId provided.");
		}
	}
	// Exception handler for TransactionLimitExceededException
	@ExceptionHandler(TransactionLimitExceededException.class)
	public ResponseEntity<ErrorResponse> handleTransactionLimitExceeded(TransactionLimitExceededException ex) {
		ErrorResponse errorResponse = new ErrorResponse();
		errorResponse.setErrorCode("TRANSACTION_LIMIT_EXCEEDED");
		errorResponse.setErrorMessage(ex.getMessage());

		return new ResponseEntity<>(errorResponse, HttpStatus.BAD_REQUEST);
	}


}