package com.insurance.Customeroptions.contracts;

import java.util.List;

import com.insurance.Customeroptions.model.CustomerData;
import com.insurance.Customeroptions.model.Faq;
import com.insurance.Customeroptions.model.FormData;
import com.insurance.Customeroptions.model.HealthInsuranceApplication;
import com.insurance.Customeroptions.model.InsurancePackages;
import com.insurance.Customeroptions.model.InsurancePolicy;


public interface InterfaceInsurancePolicyandPackageDAO {
List<InsurancePolicy> getAllInsurancePolicies();
	
	List<Faq> getAllFAQS();

	List<InsurancePolicy> getCustomerInsurancePolicy(int cust);

	List<InsurancePackages> getInsurancePackages();

	Long addCustomer(FormData loan);

	List<Faq> getGeneralFAQS();

	List<Faq> getCoverageandBenefitsFAQS();

}
