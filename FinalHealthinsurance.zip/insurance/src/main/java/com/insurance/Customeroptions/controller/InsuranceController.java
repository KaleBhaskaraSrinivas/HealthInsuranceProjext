package com.insurance.Customeroptions.controller;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.insurance.Customeroptions.contracts.InterfaceInsuranceRepository;
import com.insurance.Customeroptions.model.Claim;
import com.insurance.Customeroptions.model.ClaimApplication;
import com.insurance.Customeroptions.model.ClaimBills;
import com.insurance.Customeroptions.model.ClaimDataDTO;
import com.insurance.Customeroptions.model.CustomerData;
import com.insurance.Customeroptions.model.CustomerRequestedAmountException;
import com.insurance.Customeroptions.model.InsuranceApiError;
import com.insurance.Customeroptions.model.InsurancePolicy;
import com.insurance.Customeroptions.model.InsurancePolicySchedule;
import com.insurance.Customeroptions.model.NonActivePolicyException;
import com.insurance.Customeroptions.model.ReUpload;
import com.insurance.Customeroptions.model.Uploads;
import com.insurance.Customeroptions.model.UserData;

import jakarta.servlet.http.HttpSession;

@RestController
@RequestMapping("/customer")
public class InsuranceController {

	private static final Logger log = LoggerFactory.getLogger(InsuranceController.class);
	private final InterfaceInsuranceRepository insuranceres;
	private HttpSession session;

	Long GsessionId;
	Integer customerId;

	List<UserData> UserDataList;

	@Autowired
	public InsuranceController(InterfaceInsuranceRepository insuranceres, HttpSession httpSession) {
		this.insuranceres = insuranceres;
		this.session = httpSession;
	}

	@GetMapping("/policyActive/{customerId}")
	public int getActive(@PathVariable int customerId) {
		try {
			log.info("Getting count of active policies for customer ID: {}", customerId);
			int hospitals = insuranceres.getAllActivecount(customerId);
			log.info("Active policies count for customer ID {}: {}", customerId, hospitals);
			return hospitals;
		} catch (Exception e) {
			log.error("Error occurred while getting active policies for customer ID {}: {}", customerId,
					e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	@GetMapping("/policy/{customerId}")
	public int getInsurancePolicyCount(@PathVariable int customerId) {
		try {
			log.info("Getting count of insurance policies for customer ID: {}", customerId);
			int policyCount = insuranceres.getInsurancePolicyCountForCustomer(customerId);
			log.info("Insurance policies count for customer ID {}: {}", customerId, policyCount);
			return policyCount;
		} catch (Exception e) {
			log.error("Error occurred while getting insurance policies count for customer ID {}: {}", customerId,
					e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	@GetMapping("/policyFam/{customerId}")
	public int getInsuranceFamilyCount(@PathVariable int customerId) {
		try {
			log.info("Getting count of insurance policies for family ID: {}", customerId);
			int policyCount = insuranceres.getInsurancePolicyCountForFamily(customerId);
			log.info("Insurance policies count for family ID {}: {}", customerId, policyCount);
			return policyCount;
		} catch (Exception e) {
			log.error("Error occurred while getting insurance policies count for family ID {}: {}", customerId,
					e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	@GetMapping("/policyFamActive/{customerId}")
	public int getInsuranceActiveMember(@PathVariable int customerId) {
		try {
			log.info("Getting count of active members for family ID: {}", customerId);
			int policyCount = insuranceres.getInsuranceActiveMember(customerId);
			log.info("Active members count for family ID {}: {}", customerId, policyCount);
			return policyCount;
		} catch (Exception e) {
			log.error("Error occurred while getting active members count for family ID {}: {}", customerId,
					e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	@GetMapping("/policyActiveSum/{customerId}")
	public int getInsuranceActiveCoverage(@PathVariable int customerId) {
		try {
			log.info("Getting sum of active coverage for customer ID: {}", customerId);
			int policyCount = insuranceres.getInsuranceActiveCoverage(customerId);
			log.info("Active coverage for customer ID {}: {}", customerId, policyCount);
			return policyCount;
		} catch (Exception e) {
			log.error("Error occurred while getting active coverage for customer ID {}: {}", customerId,
					e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	@GetMapping("/policySum/{customerId}")
	public int getInsurancePolicySum(@PathVariable int customerId) {
		try {
			log.info("Getting sum of insurance policies for customer ID: {}", customerId);
			int policyCount = insuranceres.getInsurancePolicySum(customerId);
			log.info("Insurance policies sum for customer ID {}: {}", customerId, policyCount);
			return policyCount;
		} catch (Exception e) {
			log.error("Error occurred while getting insurance policies sum for customer ID {}: {}", customerId,
					e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Get insurance policy schedules by ID
	@GetMapping("/policySchedule/{id}")
	public List<InsurancePolicySchedule> listAllPolicySchedules(@PathVariable Integer id) {
		return insuranceres.ListAllPolicySchedulesById(id);
	}

	// Get insurance policy applicable dates for a customer
	@GetMapping("/policyUpcomingDate/{customerId}")
	public List<Date> getUpcomingInsurancePolicyDate(@PathVariable int customerId) {
		List<Date> policyUpcomingDate = insuranceres.getUpcomingInsuranceDate(customerId);
		return policyUpcomingDate;
	}

	// Get insurance policy applicable dates for a customer
	@GetMapping("/policyLastPaidDate/{customerId}")
	public String getLastPaidInsurancePolicyDate(@PathVariable int customerId) {
		List<Date> policyLastPaidDate = insuranceres.getLastPaidInsuranceDate(customerId);
		if (policyLastPaidDate.size() == 0)
			return "1";
		return policyLastPaidDate.toString();
	}

	// Get insurance policy expiration dates for a customer
	@GetMapping("/policyEXPDate/{customerId}")
	public List<Date> getInsurancePolicyEXPDate(@PathVariable int customerId) {
		List<Date> policyCount = insuranceres.getAllInsuranceEXPDates(customerId);
		return policyCount;
	}

	// Get insurance premium amounts for a customer
	@GetMapping("/policyPremAmount/{customerId}")
	public List<Integer> getInsurancePremiumMount(@PathVariable int customerId) {
		List<Integer> policyCount = insuranceres.getInsurancePremiumAmount(customerId);
		return policyCount;
	}
	@GetMapping("/policyDates/{customerId}")

	public List<Date> getInsurancePolicyDate(@PathVariable int customerId) {
		try {
			log.info("Getting insurance policy applicable dates for customer ID: {}", customerId);
			List<Date> policyCount = insuranceres.getAllInsuranceDates(customerId);
			log.info("Insurance policy applicable dates for customer ID {}: {}", customerId, policyCount);
			return policyCount;
		} catch (Exception e) {
			log.error("Error occurred while getting insurance policy applicable dates for customer ID {}: {}",
					customerId, e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	@PostMapping("/saveUserData")
	@ResponseBody
	public Long saveUserData(@RequestParam("username") String userName, @RequestParam("password") String password) {
		try {
			log.info("Saving user data for username: {}", userName);
			return insuranceres.saveUserData(userName, password);
		} catch (Exception e) {
			log.error("Error occurred while saving user data for username {}: {}", userName, e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	@PostMapping("/saveCustomerData")
	@ResponseBody
	public String saveCustomerData(@RequestBody CustomerData customerData, Model model) {
		try {
			log.info("Saving customer data: {}", customerData);
			customerData.setCust_status("Active");
			customerData.setCust_luudate(new Date(Calendar.getInstance().getTime().getTime()));
			int userId = (int) session.getAttribute("userId");
			int customerId = insuranceres.getCustIdByUserId((long) userId);

			model.addAttribute("customerId", customerId);
			model.addAttribute("userId", userId);
			customerData.setCust_user_id((long) session.getAttribute("userId"));
			customerData.setCust_cdate(new Date(Calendar.getInstance().getTime().getTime()));
			insuranceres.saveCustomerData(customerData);
			return "Customer data saved successfully";
		} catch (Exception e) {
			log.error("Error occurred while saving customer data: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	@RequestMapping(value = "/Customers", method = RequestMethod.GET)
	public List<CustomerData> getAllCustomers() {
		try {
			log.info("Getting all customers");
			log.trace("Trace message: Getting all customers");
			session.getAttribute("userId");
			List<CustomerData> customers = insuranceres.getAllCustomers();
			log.info("Fetched {} customers", customers.size());
			log.trace("Trace message: Fetched {} customers", customers.size());
			return customers;
		} catch (Exception e) {
			log.error("Error occurred while getting all customers: {}", e.getMessage());
			log.trace("Trace message: Error occurred while getting all customers: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	@RequestMapping(value = "/UpdateCustomers", method = RequestMethod.POST)
	public String UpdateCustomers(@RequestBody List<CustomerData> updatedCustomerData) {
		try {
			log.info("Updating customer data: {}", updatedCustomerData);
			log.trace("Trace message: Updating customer data: {}", updatedCustomerData);
			for (CustomerData customerData : updatedCustomerData) {
				customerData.setCust_status("Active");

				// Convert java.util.Date to java.sql.Date
				java.util.Date now = new java.util.Date();
				customerData.setCust_luudate(new Date(now.getTime()));
				customerData.setCust_luuser(1);

				// Set a default value for cust_cdate as SQL Date (assuming it's a Date field)
				customerData.setCust_cdate(new Date(now.getTime()));
			}
			String check = insuranceres.updateCustomersData(updatedCustomerData);
			log.info("Customer data updated successfully");
			log.trace("Trace message: Customer data updated successfully");
			return check;
		} catch (Exception e) {
			log.error("Error occurred while updating customer data: {}", e.getMessage());
			log.trace("Trace message: Error occurred while updating customer data: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	@RequestMapping(value = "/users", method = RequestMethod.GET)
	public List<UserData> getAllUsers() {
		try {
			log.info("Getting all users");
			log.trace("Trace message: Getting all users");
			List<UserData> users = insuranceres.getAllUsers();
			log.info("Fetched {} users", users.size());
			log.trace("Trace message: Fetched {} users", users.size());
			return users;
		} catch (Exception e) {
			log.error("Error occurred while getting all users: {}", e.getMessage());
			log.trace("Trace message: Error occurred while getting all users: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Handle user login
	@RequestMapping(value = "/UserLogin", method = RequestMethod.POST)
	public String userCredinitial(@RequestParam("username") String userName,
			@RequestParam("password") String password) {
		try {
			log.info("User login attempt for user: {}", userName);
			UserDataList = insuranceres.getAllUsers();
			boolean b = insuranceres.userChecking(userName, password, UserDataList);
			if (b) {
				log.info("User login successful for user: {}", userName);
				log.trace("Trace message: User login successful for user: {}", userName);
				GsessionId = (Long) session.getAttribute("userId");
				customerId = insuranceres.getCustIdByUserId(GsessionId);
				System.out.println(customerId + "inuselogin");

				return "1";
			}
			log.info("User login failed for user: {}", userName);
			log.trace("Trace message: User login failed for user: {}", userName);
			return "-1";
		} catch (Exception e) {
			log.error("Error occurred during user login: {}", e.getMessage());
			log.trace("Trace message: Error occurred during user login: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Get count of claim made in registered hospitals
	@GetMapping("/registeredHospitalsClaims/{customerId}")
	public int getRegisterHospitalById(@PathVariable int customerId) {
		try {
			log.info("Getting registered hospitals claims for customer ID: {}", customerId);
			int HospitalCount = insuranceres.getRegisterHospitalById(customerId);
			log.info("Fetched registered hospitals claims count: {}", HospitalCount);
			log.trace("Trace message: Fetched registered hospitals claims count: {}", HospitalCount);
			return HospitalCount;
		} catch (Exception e) {
			log.error("Error occurred while getting registered hospitals claims: {}", e.getMessage());
			log.trace("Trace message: Error occurred while getting registered hospitals claims: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Get count of claims made in individual hospitals
	@GetMapping("/individualHospitalsClaims/{customerId}")
	public int getIndividualHospitalsById(@PathVariable int customerId) {
		try {
			log.info("Getting individual hospitals claims for customer ID: {}", customerId);
			int IndividualCount = insuranceres.getIndividualHospitalsById(customerId);
			log.info("Fetched individual hospitals claims count: {}", IndividualCount);
			log.trace("Trace message: Fetched individual hospitals claims count: {}", IndividualCount);
			return IndividualCount;
		} catch (Exception e) {
			log.error("Error occurred while getting individual hospitals claims: {}", e.getMessage());
			log.trace("Trace message: Error occurred while getting individual hospitals claims: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Send an email with OTP
	@GetMapping("/email")
	@ResponseBody
	public String email(@RequestParam("to") String to_mail) {
		try {
			log.info("Sending email with OTP to: {}", to_mail);
			String email = to_mail;
			session.setAttribute("email", email);
			// storing generated otp
			int OTP = insuranceres.sendmail(to_mail);
			log.info("Email sent successfully to: {}", to_mail);
			log.trace("Trace message: Email sent successfully to: {}", to_mail);

			LocalTime currentTime = LocalTime.now();
			session.setAttribute("time", currentTime.plusMinutes(5));
			session.setAttribute("OTP", OTP);
			return "Email Sent Successfully";
		} catch (Exception e) {
			log.error("Error occurred while sending email with OTP: {}", e.getMessage());
			log.trace("Trace message: Error occurred while sending email with OTP: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Validate OTP
	@PostMapping(value = "/validateOTP")
	public ArrayList<String> validateOTP(@RequestParam("otp") String otp, Model model) {
		try {
			log.info("Validating OTP");
			ArrayList<String> result = new ArrayList<>();
			model.addAttribute("to", "");
			int OTP = Integer.parseInt(otp);
			ModelAndView mav = new ModelAndView();
			int originalOtp = (Integer) session.getAttribute("OTP");
			String email = (String) session.getAttribute("email");

			LocalTime time = (LocalTime) session.getAttribute("time");
			int comp = time.compareTo(LocalTime.now());
			// checking the otp sent by the user if true returning reset page else need to
			// stay in the same page with error
			// msg

			if (originalOtp == OTP && comp > 0) {
				mav.setViewName("reset");
				mav.addObject("email", email);
				result.add("success");
				result.add(GsessionId.toString());
				result.add(customerId.toString());
				log.info("OTP validation successful");
				log.trace("Trace message: OTP validation successful");
				return result;
			}
			if (comp < 0) {
				result.add("expired");
				result.add("-1");
				log.info("OTP validation failed: OTP expired");
				log.trace("Trace message: OTP validation failed: OTP expired");
				return result;
			} else {
				result.add("invalid");
				result.add("-1");
				log.info("OTP validation failed: Invalid OTP");
				log.trace("Trace message: OTP validation failed: Invalid OTP");
				return result;
			}
		} catch (Exception e) {
			log.error("Error occurred during OTP validation: {}", e.getMessage());
			log.trace("Trace message: Error occurred during OTP validation: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Reset user password
	@PostMapping("/reset")
	public String reset(Model model, @RequestParam("email") String email, @RequestParam("pwd") String pwd,
			@RequestParam("cnfpwd") String cnfpwd) {
		try {
			log.info("Resetting password for email: {}", email);
			log.trace("Trace message: Resetting password for email: {}", email);

			log.debug("Received parameters - email: {}, pwd: {}, cnfpwd: {}", email, pwd, cnfpwd);
			log.trace("Trace message: Received parameters - email: {}, pwd: {}, cnfpwd: {}", email, pwd, cnfpwd);

			log.debug("GsessionId: {}", GsessionId);
			log.trace("Trace message: GsessionId: {}", GsessionId);

			int x = insuranceres.resetpwd(email, pwd, cnfpwd, GsessionId);
			if (x > 0) {
				log.info("Password changed successfully for email: {}", email);
				log.trace("Trace message: Password changed successfully for email: {}", email);
				return "password Changed";
			} else {
				log.info("Password change failed for email: {}", email);
				log.trace("Trace message: Password change failed for email: {}", email);
				return "password not match";
			}
		} catch (Exception e) {
			log.error("Error occurred during password reset: {}", e.getMessage());
			log.trace("Trace message: Error occurred during password reset: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Handle claim data and file uploads
	@RequestMapping(value = "/claimbills", method = RequestMethod.POST)
	public String claimData(@RequestParam("file[]") MultipartFile[] files,
			@RequestParam("documentTitle") String[] documentNames, @RequestParam("claimAmount") String[] claimAmount,
			Claim claim, ClaimApplication application, Model model) {

		int policyId = claim.getClamIplcId();
		try {
			if (insuranceres.checkPolicyIdStatus(policyId)) {
				// Raise Exception here
				throw new NonActivePolicyException("Invalid policy details provided.");
			}
			if (!insuranceres.checkRequestedAmount(application.getClamIplcId(),
					application.getClaimAmountRequested())) {
				throw new CustomerRequestedAmountException("Requested amount cannot be granted", "REQAMT001");
			}

		} catch (NonActivePolicyException ex) {
			// Handle the exception here, you can log it or display an error message.
			// Return an error view or redirect to an error page if needed.
			model.addAttribute("errorMessage",
					"policy is not in active status,so you cannot claim with this details provided");
			return "errorPage";
		} catch (CustomerRequestedAmountException ex) {
			System.out.println("Caught CustomException: " + ex.getMsg());
			model.addAttribute("errorCode", ex.getErrorCode());
			model.addAttribute("errorMessage", ex.getMsg());

			return "errorPage";
		}

		insuranceres.addClaimApplication(application);
		int cid = insuranceres.addClaim(claim.getClamIplcId(), application.getClaimAmountRequested());
		System.out.println(claim.getClamIplcId());

		String uploadDir = "src/main/resources/static/file";

		try {
			// Create the target directory if it doesn't exist
			Files.createDirectories(Paths.get(uploadDir));
			int i = 0;

			for (MultipartFile file : files) {
				// Get the original file name
				System.out.println("start");
				String fileName = StringUtils.cleanPath(file.getOriginalFilename());

				// Create the target file path within the directory
				Path targetLocation = Paths.get(uploadDir).resolve(fileName);

				// Copy the file to the target location
				Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);
				String fullPath = fileName;
				ClaimBills bill = new ClaimBills();
				bill.setClbl_document_path(fullPath);
				bill.setClbl_document_title(documentNames[i]);
				bill.setClbl_claim_amount(Double.parseDouble(claimAmount[i]));
				bill.setClam_id(cid);
				insuranceres.addClaimBills(bill);
			}

			// After successfully storing all files, you can redirect to a success page or
			// return a response accordingly
			return "Success";
		} catch (IOException ex) {
			ex.printStackTrace();

		}

		return "Success";
	}
	@PostMapping("/duplicatePolicy")
	public String createPolicy(@RequestBody InsurancePolicy policy) {
		try {
			int result = insuranceres.duplicatePolicy(policy);
			if (result == 0) {
				return "Policy created successfully";
			} else {
				throw new InsuranceApiError(1, "Sorry, this policy already exists");
			}
		} catch (InsuranceApiError e) {
			return e.getMessage();
		}
	}

	// Get family members
	@GetMapping(value = "/getFamilyMembers")
	public List<String> getFamily(@RequestParam("policy") int id) {
		try {
			log.info("Fetching family members for policy ID: {}", id);
			log.trace("Trace message: Fetching family members for policy ID: {}", id);

			List<String> members = insuranceres.getFamilyByPolicy(id);

			log.info("Fetched family members successfully for policy ID: {}", id);
			log.trace("Trace message: Fetched family members successfully for policy ID: {}", id);

			return members;
		} catch (Exception e) {
			log.error("Error occurred while fetching family members: {}", e.getMessage());
			log.trace("Trace message: Error occurred while fetching family members: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Get all claims
	@GetMapping(value = "/getAllClaimsById")
	public ArrayList<Integer> getAllClaimsById(@RequestParam("customerId") Long customerId) {
		try {
			log.info("Fetching all claims for user ID: {}", customerId);
			log.trace("Trace message: Fetching all claims for user ID: {}", customerId);

			//userId = (Long) GsessionId;
			ArrayList<Integer> li = (ArrayList<Integer>) insuranceres.getAllClaims(customerId);


			log.info("Fetched {} claims for user ID: {}", li.size(), customerId);
			log.trace("Trace message: Fetched {} claims for user ID: {}", li.size(), customerId);

			return li;
		} catch (Exception e) {
			log.error("Error occurred while fetching claims: {}", e.getMessage());
			log.trace("Trace message: Error occurred while fetching claims: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Get a claim by ID
	@GetMapping(value = "/getClaimById")
	public Claim getClaimById(@RequestParam("claimId") int clamId) {
		try {
			log.info("Fetching claim by ID: {}", clamId);
			log.trace("Trace message: Fetching claim by ID: {}", clamId);

			Claim cl = insuranceres.getClaimByid(clamId);

			log.info("Fetched claim successfully for ID: {}", clamId);
			log.trace("Trace message: Fetched claim successfully for ID: {}", clamId);

			return cl;
		} catch (Exception e) {
			log.error("Error occurred while fetching claim: {}", e.getMessage());
			log.trace("Trace message: Error occurred while fetching claim: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Get all data by claim ID
	@GetMapping(value = "/getAllDataByClaimId")
	public ClaimDataDTO getAllDataByClaimId(@RequestParam("claimId") int clamId) {
		try {
			log.info("Fetching all data for claim ID: {}", clamId);
			log.trace("Trace message: Fetching all data for claim ID: {}", clamId);

			Claim cl = insuranceres.getClaimByid(clamId);
			List<ClaimBills> claimBill = insuranceres.getClaimBillById(clamId);
			List<Uploads> upload = insuranceres.getUploadByClaimId(clamId);
			List<ReUpload> reupload = insuranceres.getReUploadsByClaimId(clamId);
			int claimPolicyId = insuranceres.getclaimPolicyIdByClaimId(clamId);
			List<String> patientName = insuranceres.getPatientNameByPlocyId(claimPolicyId);

			ClaimDataDTO claimData = new ClaimDataDTO();
			claimData.setClaim(cl);
			claimData.setClaimBill(claimBill);
			claimData.setUploads(upload);
			claimData.setReuploads(reupload);
			claimData.setClaimPolicyId(claimPolicyId);
			claimData.setPatientNames(patientName);

			log.info("Fetched all data successfully for claim ID: {}", clamId);
			log.trace("Trace message: Fetched all data successfully for claim ID: {}", clamId);

			return claimData;
		} catch (Exception e) {
			log.error("Error occurred while fetching data for claim ID {}: {}", clamId, e.getMessage());
			log.trace("Trace message: Error occurred while fetching data for claim ID {}: {}", clamId, e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Get filtered claims
	@GetMapping(value = "/getFilteredClaims")
	public ArrayList<Claim> getFilteredClaims(@RequestParam("status") String status) {
		try {
			log.info("Fetching filtered claims with status: {}", status);
			log.trace("Trace message: Fetching filtered claims with status: {}", status);

			ArrayList<Claim> li = insuranceres.getFilteredClaims(status);

			log.info("Fetched {} filtered claims with status: {}", li.size(), status);
			log.trace("Trace message: Fetched {} filtered claims with status: {}", li.size(), status);

			return li;
		} catch (Exception e) {
			log.error("Error occurred while fetching filtered claims with status {}: {}", status, e.getMessage());
			log.trace("Trace message: Error occurred while fetching filtered claims with status {}: {}", status,
					e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Get required uploads for a claim
	@GetMapping(value = "/getrequired")
	public ResponseEntity<Object> getRequiredUploads(@RequestParam("claimid") int id) {
		try {
			log.info("Fetching required uploads for claim ID: {}", id);
			log.trace("Trace message: Fetching required uploads for claim ID: {}", id);

			if (!insuranceres.getAllReUploads(id).isEmpty()) {
				return ResponseEntity.ok(insuranceres.getAllReUploads(id));
			} else {
				return ResponseEntity.ok("null");
			}
		} catch (Exception e) {
			log.error("Error occurred while fetching required uploads for claim ID {}: {}", id, e.getMessage());
			log.trace("Trace message: Error occurred while fetching required uploads for claim ID {}: {}", id,
					e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Get all claim bills
	@GetMapping(value = "/getAllClaimBills")
	public List<ClaimBills> getAllClaimBills() {
		try {
			log.info("Fetching all claim bills");
			log.trace("Trace message: Fetching all claim bills");

			return insuranceres.getAllClaimBills();
		} catch (Exception e) {
			log.error("Error occurred while fetching all claim bills: {}", e.getMessage());
			log.trace("Trace message: Error occurred while fetching all claim bills: {}", e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

	// Add uploads for a claim
	@PostMapping(value = "/adduploadsFile")
	public void adduploadsFile(@RequestParam("claimId") int claimId, MultipartHttpServletRequest request) {
		try {
			log.info("Adding uploads for claim ID: {}", claimId);
			log.trace("Trace message: Adding uploads for claim ID: {}", claimId);

			insuranceres.storeData(claimId, request);

			log.info("Uploads added successfully for claim ID: {}", claimId);
			log.trace("Trace message: Uploads added successfully for claim ID: {}", claimId);
		} catch (Exception e) {
			log.error("Error occurred while adding uploads for claim ID {}: {}", claimId, e.getMessage());
			log.trace("Trace message: Error occurred while adding uploads for claim ID {}: {}", claimId,
					e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}

	}

	// Get all upload files by claim ID
	@GetMapping(value = "/getAllUploadFileById")
	public Uploads getAllUploadFilesDynamically(@RequestParam("claimid") int id) {
		try {
			log.info("Fetching all upload files for claim ID: {}", id);
			log.trace("Trace message: Fetching all upload files for claim ID: {}", id);

			return insuranceres.getAllUploadFileById(id);
		} catch (Exception e) {
			log.error("Error occurred while fetching upload files for claim ID {}: {}", id, e.getMessage());
			log.trace("Trace message: Error occurred while fetching upload files for claim ID {}: {}", id,
					e.getMessage());
			throw e; // rethrow the exception for global exception handling
		}
	}

}
