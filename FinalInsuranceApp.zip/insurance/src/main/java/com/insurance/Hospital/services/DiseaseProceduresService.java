package com.insurance.Hospital.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.insurance.Hospital.contractors.DiseaseProceduresDaoInterface;
import com.insurance.Hospital.contractors.DiseaseProceduresServiceInterface;

import com.insurance.Hospital.models.DiseaseProcedures;



@Service
public class DiseaseProceduresService implements DiseaseProceduresServiceInterface {
	
	@Autowired
	DiseaseProceduresDaoInterface diseaseProceduresDaoInterface;

	@Override
	public List<DiseaseProcedures> getProceduresByDisId(int diseaseId) {
		return diseaseProceduresDaoInterface.getProceduresByDisId(diseaseId);
	}

	@Override
	public int addProcedure(int discId, String procName, String icdCode) {
		return diseaseProceduresDaoInterface.addProcedure(discId, procName, icdCode);
	}

	@Override
	public int deleProcedure(int procId) {
		return diseaseProceduresDaoInterface.delProcedure(procId);
	}
	
	
	
}
