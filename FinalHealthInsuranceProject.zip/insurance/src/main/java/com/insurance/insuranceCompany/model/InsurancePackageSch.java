package com.insurance.insuranceCompany.model;




public class InsurancePackageSch {


	private Long id;

	private String title;

	private String description;


	private String status;


	private Double rangeStart;


	private Double rangeEnd;

	
	private Integer ageLimitStart;


	private Integer ageLimitEnd;

	public InsurancePackageSch() {
		super();
	}

	public InsurancePackageSch(Long id, String title, String description, String status, Double rangeStart,
			Double rangeEnd, Integer ageLimitStart, Integer ageLimitEnd) {
		super();
		this.id = id;
		this.title = title;
		this.description = description;
		this.status = status;
		this.rangeStart = rangeStart;
		this.rangeEnd = rangeEnd;
		this.ageLimitStart = ageLimitStart;
		this.ageLimitEnd = ageLimitEnd;
	}

	@Override
	public String toString() {
		return "InsurancePackageSch [id=" + id + ", title=" + title + ", description=" + description + ", status=" + status
				+ ", rangeStart=" + rangeStart + ", rangeEnd=" + rangeEnd + ", ageLimitStart=" + ageLimitStart
				+ ", ageLimitEnd=" + ageLimitEnd + "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Double getRangeStart() {
		return rangeStart;
	}

	public void setRangeStart(Double rangeStart) {
		this.rangeStart = rangeStart;
	}

	public Double getRangeEnd() {
		return rangeEnd;
	}

	public void setRangeEnd(Double rangeEnd) {
		this.rangeEnd = rangeEnd;
	}

	public Integer getAgeLimitStart() {
		return ageLimitStart;
	}

	public void setAgeLimitStart(Integer ageLimitStart) {
		this.ageLimitStart = ageLimitStart;
	}

	public Integer getAgeLimitEnd() {
		return ageLimitEnd;
	}

	public void setAgeLimitEnd(Integer ageLimitEnd) {
		this.ageLimitEnd = ageLimitEnd;
	}

}