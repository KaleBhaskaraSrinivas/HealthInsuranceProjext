package com.insurance.insuranceCompany.controller;

import java.time.LocalTime;

import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.insurance.insuranceCompany.model.Login;
import com.insurance.insuranceCompany.service.EmailService;
import com.insurance.insuranceCompany.service.HospitalLoginService;

@Controller
@RequestMapping("/insurance")
public class EmailController {

    private HospitalLoginService logService;
    private EmailService mailService;
    private HttpSession httpSession;
    private static final Logger logger = LoggerFactory.getLogger(EmailController.class);

    @Autowired
    public EmailController(EmailService mailService, HttpSession httpSession, HospitalLoginService logService) {
        this.mailService = mailService;
        this.httpSession = httpSession;
        this.logService = logService;
    }

    // This method handles the email sending process for password reset.
    @GetMapping("/email")
    @ResponseBody
    public String email(@RequestParam("to") String to_mail) {
        try {
            // Log that we're entering the email method
            logger.trace("Entering email method");

            // Check if the provided email exists in the system
            if (mailService.checkMail(to_mail) == 1) {
                // Store the email in the session and generate an OTP
                httpSession.setAttribute("email", to_mail);
                int OTP = mailService.sendmail(to_mail);

                // Store OTP and current time in the session
                httpSession.setAttribute("time", LocalTime.now());
                httpSession.setAttribute("OTP", OTP);

                // Log successful email sending
                logger.info("Email Sent Successfully");

                return "Email Sent Successfully";
            } else {
                // Log that the email is not registered
                logger.warn("Email not registered");
                return "Email not registered";
            }
        } catch (Exception e) {
            // Log any errors that occur during the process
            logger.error("An error occurred in email", e);
            return "An error occurred while sending the email.";
        } finally {
            // Log that we're exiting the email method
            logger.trace("Exiting email method");
        }
    }

    // This method validates the OTP entered by the user for password reset.
    @PostMapping(value = "/validateOTP")
    public ModelAndView validateOTP(@RequestParam("otp") String otp, Model model) {
        model.addAttribute("to", "");
        int enteredOTP = Integer.parseInt(otp);

        ModelAndView mav = new ModelAndView();
        int storedOtp = (Integer) httpSession.getAttribute("OTP");
        String email = (String) httpSession.getAttribute("email");
        LocalTime OtpStoredTime = (LocalTime) httpSession.getAttribute("time");
        int comp = OtpStoredTime.compareTo(LocalTime.now());

        // Check if the entered OTP is valid and within the time limit
        if (storedOtp == enteredOTP && comp <= 5) {
            mav.setViewName("reset");
            mav.addObject("email", email);
            return mav;
        }
        mav.setViewName("forgotPasswordPage");
        if (comp > 5)
            mav.addObject("msg", "OTP expired, please try again..");
        else
            mav.addObject("msg", "Invalid OTP, please try again..");
        mav.addObject("to", email);
        return mav;
    }

    // This method handles the password reset process.
    @PostMapping("/reset")
    public String reset(Model model, @RequestParam("email") String email, @RequestParam("pwd") String pwd,
                        @RequestParam("cnfpwd") String cnfpwd) {
        logger.trace("Entering reset method");

        // Attempt to reset the password
        int result = logService.resetpwd(email, pwd);
        if (result == 1) {
            logger.info("Password changed successfully");
            model.addAttribute("message", "Password changed successfully");
        } else {
            logger.warn("Error while changing password");
            model.addAttribute("message", "Error while changing password");
        }

        model.addAttribute("login", new Login());
        return "loginPage";
    }
}
