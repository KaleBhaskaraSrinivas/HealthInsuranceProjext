package com.insurance.Hospital.contractors;

import com.insurance.Hospital.models.LoginClass;

public interface LoginServiceInterface {
	
	int checkCredentials(LoginClass lc);

	int resetpwd(String email, String pwd);
}
