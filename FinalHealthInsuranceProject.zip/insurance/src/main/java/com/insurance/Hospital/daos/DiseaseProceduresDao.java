package com.insurance.Hospital.daos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.insurance.Hospital.contractors.DiseaseProceduresDaoInterface;
import com.insurance.Hospital.models.DiseaseDetails;
import com.insurance.Hospital.models.DiseaseProcedures;
import com.insurance.Hospital.rowmappers.*;

@Component
public class DiseaseProceduresDao implements DiseaseProceduresDaoInterface {

    private final JdbcTemplate jdbcTemplate;

    @Autowired(required = true)
    public DiseaseProceduresDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final String GET_DISEASE_DETAILS = "Select * from diseases";
    String GET_PROCEDURES_BY_DIS_ID = "Select * from proceduress where proc_disc_id=?";

    @Override
    public List<DiseaseProcedures> getProceduresByDisId(int diseaseId) {
        return jdbcTemplate.query(GET_PROCEDURES_BY_DIS_ID, new Object[] { diseaseId }, new DiseaseProceduresRowMapper());
    }

    @Override
    public int addProcedure(int discId, String procName, String icdCode) {
        String ADD_PROCEDURE = "INSERT INTO PROCEDURESS (proc_id, proc_disc_id, proc_name, proc_disc_icdcode) VALUES (nextval('proceduress_proc_id_seq'::regclass), ?, ?, ?)";

        try {
            // Execute the query and retrieve the generated proc_id
            jdbcTemplate.update(ADD_PROCEDURE, discId, procName, icdCode);
        } catch (Exception e) {
            e.printStackTrace();
            return -1; // Return a negative value or handle the error as needed
        }
        return discId;
    }

    @Override
    public int delProcedure(int procId) {
        System.out.println("del-------" + procId);
        String DELETE_PROCEDURE = "DELETE FROM proceduress WHERE proc_id = ?";
        jdbcTemplate.update(DELETE_PROCEDURE, procId);
        return 1;
    }
}
