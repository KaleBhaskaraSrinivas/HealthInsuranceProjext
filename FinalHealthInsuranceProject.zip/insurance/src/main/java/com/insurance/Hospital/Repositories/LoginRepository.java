package com.insurance.Hospital.Repositories;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.insurance.Hospital.contractors.LoginDaoInterface;
import com.insurance.Hospital.contractors.LoginRepositoryInterface;
import com.insurance.Hospital.models.LoginClass;

@Repository
public class LoginRepository implements LoginRepositoryInterface {

	@Autowired
	LoginDaoInterface loginDaoInterface;

	@Override
	public int sendmail(String to_mail) {
		return loginDaoInterface.sendmail(to_mail);
	}

}
