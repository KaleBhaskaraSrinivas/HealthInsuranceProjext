package com.insurance.Hospital.models;

public class NonActivePolicyException extends RuntimeException {

    public NonActivePolicyException(String message) {
        super(message);
    }
}
