package com.insurance.Hospital.contractors;

import java.util.List;
import com.insurance.Hospital.models.DiseaseProcedures;

public interface DiseaseProceduresDaoInterface {
	List<DiseaseProcedures> getProceduresByDisId(int diseaseId);
	int addProcedure(int discId, String procName, String icdCode);

	int delProcedure(int procId);
}