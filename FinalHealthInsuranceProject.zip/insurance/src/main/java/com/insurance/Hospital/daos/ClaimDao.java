package com.insurance.Hospital.daos;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.insurance.Hospital.contractors.ClaimDaoInterface;
import com.insurance.Hospital.models.Claim;
import com.insurance.Hospital.models.ClaimApplication;
import com.insurance.Hospital.models.ClaimBills;
import com.insurance.Hospital.models.PolicyMembers;
import com.insurance.Hospital.models.ReUpload;
import com.insurance.Hospital.models.Uploads;
import com.insurance.Hospital.rowmappers.ClaimMapper;
import com.insurance.Hospital.rowmappers.PolicyMembersRowMapper;
import com.insurance.Hospital.rowmappers.ReUploadRowMapper;
import com.insurance.Hospital.rowmappers.RowMap;
import com.insurance.Hospital.rowmappers.UploadsRowMapper;

@Component
public class ClaimDao implements ClaimDaoInterface {

	@Autowired
	JdbcTemplate jdbcTemplate;

	private String SQL_GET_CLAIMS = "select * from  _Claims";
	private String SQL_GET_FILTERED_CLAIMS = "select * from  _Claims where clam_status=?";
	private String SQL_GET_CLAIM_BY_ID = "select * from  _Claims where clam_id=?";

	@Override
	public ArrayList<Claim> getAllClaims() {
		System.out.println("bhav");
		return (ArrayList<Claim>) jdbcTemplate.query(SQL_GET_CLAIMS, new ClaimMapper());
	}

	@Override
	public ArrayList<Claim> getFilteredClaims(String status) {
		// TODO Auto-generated method stub
		return (ArrayList<Claim>) jdbcTemplate.query(SQL_GET_FILTERED_CLAIMS, new Object[] { status },
				new ClaimMapper());
	}

	@Override
	public Claim getClaimById(int clamId) {
		// TODO Auto-generated method stub
		return jdbcTemplate.queryForObject(SQL_GET_CLAIM_BY_ID, new Object[] { clamId }, new ClaimMapper());
	}

	// New Claim

	private String SQL_INSERT_CLAIM = "insert into _Claims(clam_source,clam_type,clam_date,clam_amount_requested,clam_iplc_id,pay_status,hosp_name) values(?,?,?,?,?,?,?)";
	private String SQL_INSERT_CLAIMBill = "insert into Claim_Bills(clam_id,clbl_document_title,clbl_document_path,clbl_claim_amount) values(?,?,?,?)";

	@Override
	public void addClaimApplication(ClaimApplication application) {
		System.out.println(application.getMemberIndex() + 1);
		String query = "insert into insurance_claim(policy_id,member_index,relation,joined_date,patient_name,date_of_birth,gender,contact_number,address,disease,diagnosis,treatment,claimAmount) values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
		Object[] values = { application.getClamIplcId(), application.getMemberIndex(), application.getRelation(),
				application.getJoinedDate(), application.getPatientName(), application.getDateOfBirth(),
				application.getGender(), application.getContactNumber(), application.getAddress(),
				application.getDisease(), application.getDiagnosis(), application.getTreatment(),
				application.getClaimAmountRequested() };
		jdbcTemplate.update(query, values);
	}

	@Override
	public void addClaim(int i, double requestAmount, String hospname) {
		try {
			String currentDate = LocalDate.now() + "";
			Date sqlDate = Date.valueOf(currentDate);
			jdbcTemplate.update(SQL_INSERT_CLAIM, "HSPT", "DRCT", sqlDate, requestAmount, i, "pending...", hospname);
		} catch (Exception e) {

			e.printStackTrace();
		}

	}

	@Override
	public void addClaimBills(ClaimBills bill) {

		jdbcTemplate.update(SQL_INSERT_CLAIMBill, bill.getClam_id(), bill.getClbl_document_title(),
				bill.getClbl_document_path(), bill.getClbl_claim_amount());
	}

	@Override
	public Claim getClaimByid(int clamIplcId) {
		// TODO Auto-generated method stub

		return jdbcTemplate.queryForObject(
				"select distinct clam_id from _Claims where clam_iplc_id=" + clamIplcId + " limit 1", new RowMap());
	}

	@Override
	public List<PolicyMembers> getFamilyByPolicy(int id) {

		return jdbcTemplate.query(
				"select ipcm_mindex,iplc_id, ipcm_membername, ipcm_relation from insurancepolicycoveragemembers",
				new PolicyMembersRowMapper());
	}

	//////////////////////////////

	// Reupload

	@Override
	public void addRequiredUploads(ReUpload upload) {
		String query = "insert into reuploads(claimId,name,type,Status,description) values(?,?,?,?,?)";
		Object[] values = { upload.getClaimId(), upload.getName(), upload.getType(), upload.getStatus(),
				upload.getDescription() };
		jdbcTemplate.update(query, values);
	}

	@Override
	public List<ReUpload> getAllReUploads(int id) {

		return jdbcTemplate.query("select * from reuploads where status is null and claimId=" + id,
				new ReUploadRowMapper());
	}

	@Override
	public void addUploads(Uploads up) {

		System.out.println("jdbc");
		String query = "insert into uploads(uploadId,reuploadId,claimId,data,type) values(?,?,?,?,?)";
		Object[] values = { up.getUploadId(), up.getReUploadId(), up.getClaimId(), up.getData(), up.getType() };
		jdbcTemplate.update(query, values);
	}

	@Override
	public List<Uploads> getAllUploads(int claimId) {

		Object[] values = { claimId };

		return jdbcTemplate.query("select * from uploads where claimId=?", values, new UploadsRowMapper());
	}

	@Override
	public void updateReUploads(int uploadId, int claimId) {

		jdbcTemplate.update("update reuploads set Status=? where uploadid=? and claimId=?", "uploaded", uploadId,
				claimId);
	}

	@Override
	public boolean checkPolicyIdStatus(int policyId) {
		String sql = "select count(*) from insurancepolicies1 where iplc_id=? and iplc_status='pending'";
		return jdbcTemplate.queryForObject(sql, Integer.class) > 0;
	}

	@Override
	public boolean checkRequestedAmount(int pid, double requestedClaimAmount) {

		double totalProcessedAmountClaimed;
		if (jdbcTemplate.queryForObject("select sum(clam_processed_amount) from _claims where clam_iplc_id=?",
				Double.class, pid) != null)
			totalProcessedAmountClaimed = jdbcTemplate.queryForObject(
					"select sum(clam_processed_amount) from _claims where clam_iplc_id=?", Double.class, pid);
		else
			totalProcessedAmountClaimed = 0;
		double packageAmount = jdbcTemplate
				.queryForObject("select iplc_sum_assured from Insurancepolicies1 where iplc_id=?", Double.class, pid);
		if (totalProcessedAmountClaimed + requestedClaimAmount > packageAmount)
			return false;
		return true;
	}

}
