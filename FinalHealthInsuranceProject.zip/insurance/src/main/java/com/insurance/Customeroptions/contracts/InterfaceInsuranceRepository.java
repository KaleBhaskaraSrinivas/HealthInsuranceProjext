package com.insurance.Customeroptions.contracts;

import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.insurance.Customeroptions.model.AuthUtils;
import com.insurance.Customeroptions.model.Claim;
import com.insurance.Customeroptions.model.ClaimApplication;
import com.insurance.Customeroptions.model.ClaimBills;
import com.insurance.Customeroptions.model.CustomerData;
import com.insurance.Customeroptions.model.FamilyMedicalHistoryData;
import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicySchedule;
import com.insurance.Customeroptions.model.ReUpload;
import com.insurance.Customeroptions.model.Uploads;
import com.insurance.Customeroptions.model.UserData;
import com.insurance.Customeroptions.model.UserLoginValidation;

public interface InterfaceInsuranceRepository {
	
	public int getInsurancePolicyCountForCustomer(int customerId);

	public int getInsurancePolicyCountForFamily(int customerId);
	public int getAllActivecount(int customerId) ;

	public int getInsurancePolicySum(int customerId) ;

	public List<Date> getAllInsuranceDates(int customerId) ;

	public List<Date> getAllInsuranceEXPDates(int customerId) ;

	public List<Integer> getInsurancePremiumAmount(int customerId) ;

	public List<String> getApplicantName(int customerId) ;

	public List<String> getApplicantRelation(int customerId) ;

	public List<InsurancePolicySchedule> ListAllPolicySchedulesById(int id);

	public Long saveUserData(String userName, String password) ;

	public void saveCustomerData(CustomerData customerData) ;


	public List<CustomerData> getAllCustomers();

	public List<UserData> getAllUsers() ;

	public String uploadFile(MultipartFile file) ;

	public List<String> getPdfFileNames() ;

	public int sendmail(String to_mail) ;

	public void sendEmail(String to, String subject, String body) ;

	public int generateOTP();

	public int resetpwd(String email, String pwd, String cnfpwd, Long gsessionId) ;
	

	public String updateCustomersData(List<CustomerData> updatedCustomerData) ;

	public boolean userChecking(String userName, String password, List<UserData> userDataList) ;

	public Claim getClaimByid(int clamIplcId) ;
	public void addClaimBills(ClaimBills bill) ;

	public void addClaimApplication(ClaimApplication application) ;

	public int addClaim(int clamIplcId, double claimAmountRequested) ;

	public ArrayList<Claim> getFilteredClaims(String status) ;

	public List<Integer> getAllClaims(Long userId) ;

	public List<String> getFamilyByPolicy(int id) ;

	public int getCustIdByUserId(Long gsessionId) ;

	public List<ReUpload> getAllReUploads(int id) ;
	public List<Uploads> getAllUploads(int claimId);

	public void addUploads(Uploads up) ;

	public List<ClaimBills> getAllClaimBills() ;

	public void updateStatus(int claimId) ;

	public Uploads getAllUploadFileById(int id) ;

	public boolean checkPolicyIdStatus(int policyId);

	public void storeData(int claimId, MultipartHttpServletRequest request);
	Boolean checkRequestedAmount(int clamIplcId, double claimAmountRequested);

	public int getInsuranceActiveMember(int customerId);
	public int getInsuranceActiveCoverage(int customerId) ;

	public int getRegisterHospitalById(int customerId);

	public int getIndividualHospitalsById(int customerId);

	public List<Date> getUpcomingInsuranceDate(int customerId);

	public List<Date> getLastPaidInsuranceDate(int customerId);

	public List<ClaimBills> getClaimBillById(int clamId);

	public List<Uploads> getUploadByClaimId(int clamId);

	public List<ReUpload> getReUploadsByClaimId(int clamId);

	public int getclaimPolicyIdByClaimId(int clamId);

	public List<String> getPatientNameByPlocyId(int clamId);

}
