package com.insurance.Customeroptions.contracts;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import com.insurance.Customeroptions.model.Claim;
import com.insurance.Customeroptions.model.ClaimApplication;
import com.insurance.Customeroptions.model.ClaimBills;
import com.insurance.Customeroptions.model.CustomerData;
import com.insurance.Customeroptions.model.InsurancePolicyCoverageMembers;
import com.insurance.Customeroptions.model.InsurancePolicySchedule;
import com.insurance.Customeroptions.model.ReUpload;
import com.insurance.Customeroptions.model.Uploads;
import com.insurance.Customeroptions.model.UserData;
import com.insurance.Customeroptions.model.UserLoginValidation;

public interface InterfaceInsuranceDAO {

	int getAllActivecountList(int customerId);

	List<Integer> getInsurancePremium(int customerId);

	List<Date> getInsuranceDates(int customerId);

	List<Date> getInsuranceEXPDates(int customerId);

	int getInsuranceSum(int customerId);

	int getInsurancePolicyCountForCustomer(int customerId);

	List<String> getApplicantName(int customerId);

	List<String> getApplicantRelation(int customerId);

	List<InsurancePolicySchedule> getAllScheduleById(int id);

	long saveUserData(String userName, String password);

	void saveCustomerData(CustomerData customerData);

	List<CustomerData> getAllCustomersFromDao();

	List<UserData> getAllUsersFromDao();

	List<String> getPdfFileNames();

	int resetpwd(String email, String pwd, Long gessionId);

	void updateCustomersData(List<CustomerData> updatedCustomerData);

	int getInsurancePolicyCountForFamily(int customerId);


	public Claim getClaimByid(int clamIplcId);

	public void addClaimBills(ClaimBills bill);

	public void addClaimApplication(ClaimApplication application);

	public int addClaim(int clamIplcId, double claimAmountRequested);

	public ArrayList<Claim> getFilteredClaims(String status);

	public List<Integer> getAllClaims(Long userId);

	public List<InsurancePolicyCoverageMembers> getPoliMem();

	public int getCustIdByUserId(Long userId);

	public void addRequiredUploads(ReUpload upload);

	public List<ReUpload> getAllReUploads(int id);

	public void addUploads(Uploads up);

	public List<Uploads> getAllUploads(int claimId);

	public List<ClaimBills> getAllClaimBills();
	
	public Uploads getAllUploadFileById(int id);

	boolean checkPolicyIdStatus(int policyId);

	void updateStatus(int claimId);

	String uploadFileToDao(MultipartFile file);
	Boolean checkRequestedAmount(int pid, double requestedClaimAmount);

	int getInsuranceActiveMember(int customerId);

	int getInsuranceActiveCoverage(int customerId);

	int getRegisterHospitalById(int customerId);

	int getIndividualHospitalsById(int customerId);

	List<Date> getUpcomingInsuranceDates(int customerId);

	List<Date> getLastPaidInsuranceDates(int customerId);

	List<ClaimBills> getClaimBillById(int clamId);

	
	List<Uploads> getUploadByClaimId(int clamId);

	List<ReUpload> getReUploadsByClaimId(int clamId);

	int getclaimPolicyIdByClaimId(int clamId);

	List<String> getPatientNameByPlocyId(int clamId);
	
	

}
